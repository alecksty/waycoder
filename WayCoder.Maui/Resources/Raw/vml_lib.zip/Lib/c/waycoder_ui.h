/* waycoder_ui.h —— 手机端 UI syscall 的 C 语言**声明**（对话框 / 窗体 / 绘图 / 输入）
 *
 * ## 实现在哪
 *
 * 函数体在 **`Lib/shared/src/vmlui.c`**，编成 `Lib/shared/vmlui.vml` 后由
 * `vmltool.config.xml` 挂到各语言的 `Libs` 上 —— **C 与 Python 等前端共用同一份实现**。
 * 本头文件只提供声明与常量，`#include` 它不会让程序变大。
 *
 * （早先这层是写在头文件里自带实现的。挪出去的原因：Python 等前端**不支持内联 asm**，
 *   只能按标签调 C 函数 —— 实现留在 `.h` 里，那些语言就一个都调不到，
 *   于是同一套接口会被迫各写一遍。那是本仓库排第一的坑。）
 *
 * ## 号段
 * 500–599 是**宿主 UI 保留段**，只有手机 App（WayCoder）里能用；桌面 vmltool 不认识
 * 这些号。号段表见 `Lib/README-ui.md`。
 *
 * ## 用法（C）
 *
 *     #include <waycoder_ui.h>
 *
 *     int main(void) {
 *         int msg[4];
 *         ui_win_open("演示", 360, 620);
 *         ui_clear(0xFF101020);
 *         ui_set_font(18, VML_FONT_BOLD, 0xFFFFFFFF, VML_ANCHOR_CENTER);
 *         ui_text_cur(180, 40, "按方向键退出");
 *         ui_present();
 *         while (ui_win_closed() == 0) {
 *             if (ui_wait(msg, 0) != VML_MSG_TOUCHDOWN) continue;   // msg[1]=x msg[2]=y
 *         }
 *         return 0;
 *     }
 *
 * 文本按 **UTF-8**（NUL 结尾）传给宿主，源文件存成 UTF-8 即可直接写中文。
 */

/* ⚠ 本头文件要能被 **Objective-C** 源文件 `#include` —— 所以形式参数**不能叫 `id`**
 *   （`id` 在 ObjC 里是保留的**类型名**，形参位置写它会让 ObjC 前端报
 *   `expected ) (got IdType 'id')`）。原型里的形参名对 C 没有任何语义，改名零风险。
 *   实测（2026-09-19）：`Examples/objc/*.m` 引这个头一直是报错的，
 *   台账里那条「别引头文件、直接调用」的绕过就是这么来的。 */
#ifndef WAYCODER_UI_H
#define WAYCODER_UI_H

/* ── 消息类型（与 UI/Shared/VmlUiProtocol.cs 的 VmlMsgType 一一对应）── */
#define VML_MSG_NONE          0
#define VML_MSG_KEYDOWN       1
#define VML_MSG_KEYUP         2
#define VML_MSG_MOUSEMOVE     3
#define VML_MSG_MOUSEDOWN     4
#define VML_MSG_MOUSEUP       5
#define VML_MSG_TOUCHDOWN     6
#define VML_MSG_TOUCHMOVE     7
#define VML_MSG_TOUCHUP       8
#define VML_MSG_TIMER         9
#define VML_MSG_WINDOWCLOSE  10
#define VML_MSG_WINDOWRESIZE 11
/* 方向变了：msg[1] = 新方向（VML_ORIENT_*）。宿主**先发方向、后发尺寸**，
   所以处理 WINDOWRESIZE 时读到的方向已经是新的。 */
#define VML_MSG_WINDOWORIENT 12

/* ── 屏幕方向（ui_orientation() 的返回值）── */
#define VML_ORIENT_PORTRAIT   0
#define VML_ORIENT_LANDSCAPE  1

/* ── 键码（Win32 虚拟键值；手柄那一排见 VmlKeys）── */
#define VML_KEY_BACKSPACE  8
#define VML_KEY_ENTER     13
#define VML_KEY_SELECT    16    /* 手柄 SELECT */
#define VML_KEY_PAUSE     19    /* 手柄 PAUSE */
#define VML_KEY_ESCAPE    27
#define VML_KEY_SPACE     32
#define VML_KEY_LEFT      37
#define VML_KEY_UP        38
#define VML_KEY_RIGHT     39
#define VML_KEY_DOWN      40
#define VML_KEY_PAD_A     65    /* 'A' */
#define VML_KEY_PAD_B     66    /* 'B' */
#define VML_KEY_PAD_X     88    /* 'X' */
#define VML_KEY_PAD_Y     89    /* 'Y' */

/* ── 对话框样式 ── */
#define VML_DLG_INFO     0
#define VML_DLG_WARN     1
#define VML_DLG_ERROR    2
#define VML_DLG_QUESTION 3

/* ── 文字样式位 / 锚点 ── */
#define VML_FONT_BOLD    1
#define VML_FONT_ITALIC  2
#define VML_ANCHOR_LEFT   0
#define VML_ANCHOR_CENTER 1
#define VML_ANCHOR_RIGHT  2

/* ── 文字**竖对齐**（配 `ui_text_v`；老接口没有这一档）──
 *
 * 缺这一档时，程序写"横中"只能得到**横向居中、纵向顶着 y** —— 摆在方框/按钮正中看着偏上。
 * 修之前每个程序都得自己按字号估半个行高，还估不准。
 * 默认（TOP）就是老行为，所以老程序一个字都不用改。 */
/* 编号是**跨语言契约**：0 留给老行为，新档位往后加（改 0 的含义 = 悄悄挪动所有既有程序）。 */
#define VML_VANCHOR_BASE   0   /* `y` **就是基线**（字形坐在基线上）—— **默认**，也是老行为 */
#define VML_VANCHOR_MIDDLE 1   /* 盒竖直中心落在 `y`（"在方框/圆里居中"用这一档） */
#define VML_VANCHOR_BOTTOM 2   /* 盒底落在 `y` */
#define VML_VANCHOR_TOP    3   /* 盒顶落在 `y`（与基线相差一个"上升"，≈0.8×字号） */

/* ── 对话框 ── */
int  ui_dlg_msg(char* title, char* body, int style);
int  ui_dlg_select(char* title, char* body, char* opts, int n, int def);
int  ui_dlg_multi(char* title, char* body, char* opts, int n);
int  ui_dlg_input(char* title, char* prompt, char* buf, int cap);

/* ── 窗体 ── */
int  ui_win_open(char* title, int w, int h);
/* 开窗（带两个声明）。两条都在**开窗之前**就生效 —— 所以按 SCR_W/H 排的版一开始就是对的，
   不会"先按小画布排一次、再收到 resize 重排"。
   老程序照旧用 ui_win_open()（走 #520，宿主那边默认就是"支持旋转 + 要手柄"）。 */
int  ui_win_open_ex(char* title, int w, int h, int rotatable, int gamepad);

/* 第 4 个参数（转屏声明），三选一：
     VML_WIN_PORTRAIT  —— 只支持竖屏（棋盘类）。屏幕**锁在竖屏**，用户怎么转都不动。
     VML_WIN_ROTATABLE —— 支持旋转（默认）。两种排版都写好了 ⇒ 视口一变宿主就发
                          VML_MSG_WINDOWORIENT + VML_MSG_WINDOWRESIZE，并把**新的坐标空间**
                          整个给到窗口（程序按新尺寸重排版即可）。
     VML_WIN_LANDSCAPE —— 只支持横屏（赛车 / 横版过关）。锁在横屏。
   ⚠ 只有 ROTATABLE 那一档会换坐标系。窗口空间被换掉之后，不重新排版的程序会继续按
     老坐标画 ⇒ 内容被裁掉一大截 —— 所以"没声明"（老接口）保持"跟随旋转但坐标系不动"。 */
#define VML_WIN_PORTRAIT     0
#define VML_WIN_ROTATABLE    1
#define VML_WIN_LANDSCAPE    2

/* 第 5 个参数（要不要屏幕手柄区）：
     VML_WIN_NO_GAMEPAD  —— 整块手柄区连同折叠条一起不显示，画布吃满整屏
                            （画图表 / 放幻灯片那种不用手柄的程序）。
     VML_WIN_NEED_GAMEPAD —— 显示（默认）。 */
#define VML_WIN_NEED_GAMEPAD 1
#define VML_WIN_NO_GAMEPAD   0

/* ── 第三种窗口：电脑屏（给老程序用）─────────────────────────────────────
 *
 *   int ui_win_open_pc(char* title, int w, int h, int rotatable, int keyboard);
 *
 * 与 ui_win_open_ex 的三点差别：
 *   ① **坐标系固定**为 (w,h)、永不重排 ⇒ 这里的 rotatable **没有"支持旋转"那一档**，
 *      它只决定锁不锁方向：VML_WIN_PORTRAIT 锁竖 / VML_WIN_LANDSCAPE 锁横 /
 *      其它（含 VML_WIN_ROTATABLE）= 不锁（跟着设备转，但坐标系不动）。
 *   ② 触摸**只当鼠标**（发 MouseDown/Move/Up，不发 Touch*）。
 *   ③ 带**屏幕键盘**而不是手柄区 ⇒ 第 5 个参数是 keyboard 而不是 gamepad：
 *        VML_WIN_NEED_KEYBOARD(1) 显示（默认） / VML_WIN_NO_KEYBOARD(0) 关掉、画布吃满整屏。
 *
 * 画图照旧走 ui_*（ui_clear / ui_rect / ui_line / ui_text …）—— **不碰显存**。 */
#define VML_WIN_NEED_KEYBOARD 1
#define VML_WIN_NO_KEYBOARD   0
int  ui_win_open_pc(char* title, int w, int h, int rotatable, int keyboard);

int  ui_win_close(void);
int  ui_win_closed(void);
int  ui_scr_w(void);
int  ui_scr_h(void);
/* 屏幕方向：VML_ORIENT_PORTRAIT(0) / VML_ORIENT_LANDSCAPE(1)。
   **开窗之前就能问** —— 程序据此决定"棋盘放左、面板放右"还是"上下排"。
   别拿 ui_scr_w() > ui_scr_h() 去推：那两个数是可用**绘图区**，
   会随宿主排版（手柄收起/展开）变，而方向是设备本身的属性。
   运行中方向变了，宿主会先发 VML_MSG_WINDOWORIENT（msg[1]=新方向）再发
   VML_MSG_WINDOWRESIZE（msg[1]=新宽 msg[2]=新高），收到后重新问一次本函数再重排版
   —— 前提是开窗时声明了 VML_WIN_ROTATABLE（老接口不换坐标系，见上）。 */
int  ui_orientation(void);

/* ── 绘图 ── */
void ui_clear(int color);
void ui_pixel(int x, int y, int color);
void ui_line(int x1, int y1, int x2, int y2, int color, int lw);
void ui_rect(int x, int y, int w, int h, int color, int fill, int lw, int radius);
void ui_circle(int cx, int cy, int r, int color, int fill, int lw);
void ui_ellipse(int cx, int cy, int rx, int ry, int color, int fill, int lw);

/* ── 绘图状态：裁剪 / 透明度 / 蒙版 / 图层（`ui_gfx`，SYSCALL #595）────────
 *
 * **一个号做多路复用**（宿主认的号段 500–599 到 594 只剩 595–599 五个，
 * 而状态操作有八九个）。
 *
 * ⚠ 这里早期写着「目前实现三个操作，蒙版/图层留号未实现」—— **那句已过期**
 *   （v0.96.481 逐条核实：op 0–16 全部接好，声明也都在本文件下面）。
 *
 * 裁剪是**可嵌套**的：每次 push 与上一级**求交**，pop 恢复上一级。
 * 用处：只让内容画在某个框里（HUD 面板、滚动视图、异形窗口、
 * 以及在墙上凿一个真正的洞 —— 后者不必再靠"逐行盖色"模拟）。
 *
 * ⚠ `ui_alpha` 只影响**形状的填充与描边**：它是在宿主把颜色写进绘制流时
 *   乘进 alpha 通道的，而**渐变与图片**的颜色不走那条路 ⇒ 不受它影响。
 *   要么等将来做成真正的图层混合，要么这两样别指望它。
 */
int ui_clip_push(int x, int y, int w, int h);   /* 压入一级矩形裁剪 */
int ui_clip_pop(void);                         /* 弹出一级（没有可弹的就什么都不做）*/
int ui_alpha(int v);                           /* 全局透明度 0..255（对之后的图元生效）*/

/* 释放**本窗口累积的全部画刷/渐变定义**。
 *
 * ⚠ 画刷句柄就是内部表的下标 ⇒ 删单个会让后面的句柄错位，所以只能整体重置。
 *   按需造渐变的程序应当**每帧开头调一次**（否则定义会一直累积到上限）。
 *   图像与图块**不受影响** —— 它们各有按句柄的释放（见 ui_free_image / ui_free_block）。
 *   重置后旧的 `@名字` 引用解析不到，按既有约定**退化成纯色**（不会崩）。 */
int ui_brush_reset(void);

/* 清空**整个裁剪栈**（不是弹一级）—— 给出错恢复用：程序中途 return/走别的分支时，
 * 压进去的那几级没人弹，后面的东西就全画不出来、而且看不出原因。配 ui_alpha(255) 复位。 */
int ui_clip_reset(void);

/* 查当前占用（a：0=场景图元数 1=图像数 2=矢量图块数 3=画刷/渐变数；未知返回 -1）。
 *
 * ⚠ 各类都有**硬上限，而且是到了上限就静默丢弃** ⇒ "防资源爆炸"光有释放口还不够，
 *   程序得看得见"快满了"。提前查、提前放，比撞上限再猜有用得多。
 *   典型用法：每帧开头 `if (ui_res_count(3) > 200) ui_brush_reset();` */
int ui_res_count(int what);

/* ── 图层（离屏合成）────────────────────────────────────────────────────
 *
 *   ui_layer_begin();
 *     ui_circle(…);  ui_text(…);         // 这一组先画进临时画布
 *   ui_layer_end(120);                    // 再**整层**按 120/255 的透明度合成上去
 *
 * 与 `ui_alpha` 的区别：`ui_alpha` 是"之后每个图元各自半透明" ——
 * **组内重叠的地方会互相透出来**（两个半透明红叠在一起，交界处更深）。
 * 图层是"先画好一整张、再整张压上去" —— 组内怎么重叠都**只透一次**，
 * 那才是"整体淡入/整体半透明"该有的样子。
 *
 * ⚠ **代价**：每层一块与窗口同尺寸的临时画布 + 一次逐像素合成。
 *   别开太多（一层一屏像素的量级）。
 * ⚠ 用了图层的这一帧**在手机上会回退光栅**（矢量后端没有离屏合成的通用做法）——
 *   与蒙版布尔运算里的 INTERSECT/XOR 是同一条取舍：宁可慢，别画错。
 * ⚠ 层内的绘制**不受外层裁剪/蒙版约束**，但"整层贴回来"这一步**受**
 *   （它是一次正常的落笔）。要"整层只在某个区域里出现"，就在外面套一层裁剪。
 */
int ui_layer_begin(void);          /* 开始收集（这期间的图元先落在临时画布上）*/
int ui_layer_end(int alpha);       /* 结束并整层合成：alpha 0..255（255 = 不透明）*/

/* ── 蒙版（任意形状 + 布尔运算）─────────────────────────────────────────
 *
 *   ui_mask_begin();
 *     ui_circle(200, 200, 120, 0xFFFFFFFF, 1, 0);   // 圆的蒙版（这些形状**不上屏**）
 *   ui_mask_end(1);                                  // 1 = 只在圆内画 / 0 = 只在圆外画
 *   ...后续绘制只在该蒙版内(外)可见，直到下一条蒙版...
 *   ui_mask_clear();                                 // 取消蒙版，恢复全部可见
 *
 * **布尔运算**：`ui_mask_end2(op)` 把新形状与**当前**蒙版组合（老式的"圆环"要画两遍，
 * 现在一次就够）：
 *
 *   ui_mask_begin();  ui_circle(200,200,120,0xFFFFFFFF,1,0);  ui_mask_end(1);
 *   ui_mask_begin();  ui_circle(200,200, 60,0xFFFFFFFF,1,0);  ui_mask_end2(VML_MASK_SUBTRACT);
 *   // ⇒ 一个甜甜圈。后面画的东西只落在环上。
 *
 * ⚠ `ui_mask_end2` **不碰 inside**（保持当前值，默认 1）—— inside 是"最后要不要整体取反"，
 *   与形状之间的组合是**正交**的两件事。所以 `inside=0` 配 `SUBTRACT` 的结果是
 *   `非(环)`，而不是"环的反面再挖一次"。
 *
 * ⚠ 蒙版形状认**圆 / 矩形 / 多边形**（矩形的圆角参数忽略）—— 它们能做**闭式判定**，
 *   于是光栅那条不需要离屏缓冲、也不需要把图元表走两遍。
 *   别的形状（椭圆/星形/文字/图片）**会被忽略**，不是"看着支持了其实不生效"。
 *   多边形来自 `ui_polygon` 与 `ui_path` —— **`ui_path` 的曲线（贝塞尔/圆弧）会先按
 *   SVG 规范展平**再当蒙版，与它当图元画时用的是同一个展平器，所以边界严丝合缝。
 *
 * ⚠ 矢量后端目前**回退光栅**（整窗），所以用了蒙版的程序在手机上会走慢的那条路。
 *   要做实是接到平台的 ClipPath 上，见 docs/VML宿主接口.md §10.1。
 */
int ui_mask_begin(void);
int ui_mask_end(int inside);
int ui_mask_clear(void);

/* 布尔运算符（`ui_mask_end2` 的参数）。数值是**跨语言契约**，别改。 */
#define VML_MASK_REPLACE   0   /* 取代当前蒙版（= ui_mask_end 的老行为）*/
#define VML_MASK_UNION     1   /* 与新形状取并 */
#define VML_MASK_INTERSECT 2   /* 与新形状取交 */
#define VML_MASK_SUBTRACT  3   /* 从当前蒙版里挖掉新形状 */
#define VML_MASK_XOR       4   /* 与新形状取异或 */

/* 结束收集，并与**当前蒙版**按 op 组合（op 取上面的 VML_MASK_*）。
 * ⚠ 不认得的 op 会**整条忽略**（返回 0），不会当成 REPLACE —— 免得"程序写错了"
 *   表现成"画面莫名其妙不一样"。 */
int ui_mask_end2(int op);

/* ── 蒙版当碰撞体 ──────────────────────────────────────────────────────
 *
 * 查"这一点在不在**当前蒙版**里"：1 = 在（= 会画出来的地方）/ 0 = 不在。
 *
 * 蒙版既然已经是"可见区域"的几何定义，它顺手就是一份碰撞体 —— 建筑层"炸一块缺一块"
 * 之后，程序不必再自己维护一份洞的坐标表来判"这一枪能不能穿过破洞"：
 *
 *     if (ui_mask_test(ban.x, ban.y) == 0) { 撞墙了; }   // 楼减洞之后，洞口是"可见的"
 *
 * ⚠ **没有蒙版时恒为 1**（处处可见）—— 与绘制那边"没有蒙版就全画"是同一条口径。
 * ⚠ 坐标是**场景坐标**（与 `ui_rect` 一致），不是放大后的画布坐标。
 * ⚠ **别每像素调**：一次查询要在形状表上跑一遍（洞多时是几十次命中测试）。
 *   判"香蕉/子弹"这类每帧几个点正合适；逐像素扫描请走 `ui_get_pixel`。
 */
int ui_mask_test(int x, int y);

/* ── 手机特有的操作方式 ─────────────────────────────────────────────────
 *
 * 这一批的共同点：桌面端没有对应的**输入源**（没有手指、没有重力），
 * 但接口本身是跨端的 —— 桌面照常接受调用，只是拿不到真实输入。
 */

/* 多点触控：第 slot 根手指（slot = 0..9）现在在哪、按着没有。
 *
 * C 里直接收进一个数组（与 `ui_wait(msg, 0)` 同一套"写进调用方缓冲区"）：
 *
 *     int t[3];
 *     if (ui_touch(0, t)) { x = t[0]; y = t[1]; if (t[2]) { ... } }
 *
 * 拿不到指针的语言（Python/BASIC/…）走下面那四个：
 *
 *     ui_touch_query(0);
 *     x = ui_touch_x();  y = ui_touch_y();  if ui_touch_down(): ...
 *
 * ⚠ 这是**轮询**：程序要自己每帧查。事件式的触摸仍是 `ui_wait_msg` 那套
 *   （`VML_MSG_TOUCHDOWN` 等），两者并存 —— 队列记"发生过什么"，这里记"此刻是什么样"。
 * ⚠ 查询本身很轻（读三个数），但**别放进逐像素循环**。 */
int ui_touch(int slot, int* out);  /* out[0]=x out[1]=y out[2]=按下；返回 1=有效（槽位越界 0）*/
int ui_touch_query(int slot);      /* 查一次并缓存（返回同上），下面三个读缓存 */
int ui_touch_x(void);              /* 缓存里的 x */
int ui_touch_y(void);              /* 缓存里的 y */
int ui_touch_down(void);           /* 缓存里的"按下" */

/* 「持续按住左移」这类逻辑不必自己维护状态表。
 *
 * ⚠ 但它**治不了丢 KeyUp**：手指划出按键范围、系统吃掉 CANCEL 都会让 `KeyUp` 永远不来，
 *   而查询只会一直报"按着"。**连发逻辑仍然要自带刹车**
 *   （见 `Examples/c/tetris.c` 里那个"按了没动两次就停 / 总拍数上限"）。 */
int ui_key_down(int key);          /* 虚拟键码（VML_KEY_*）→ 1 = 此刻按住 */

/* 锁定屏幕方向。⚠ 与 `ui_win_open_ex` 的 `rotatable` 是**两件事**：
 *   那个决定"转屏时**窗口**跟不跟"，这个决定"**系统**让不让转"（改设备的 user_rotation）。 */
#define VML_LOCK_PORTRAIT   0
#define VML_LOCK_LANDSCAPE  1
#define VML_LOCK_AUTO       2
int ui_orient_lock(int mode);

/* 隐藏 / 恢复状态栏与导航栏（全屏游戏）。`on` = 1 隐藏。 */
int ui_immersive(int on);

/* ── 音频（541，一个号 + 操作码）────────────────────────────────────────
 *
 * ⚠ 底层只有一个 syscall 号（541），`R0` 是操作码（下面这组宏）、参数从 `R1` 起。
 *   原先这里是 541/542/543/547 **四个号**（v0.96.484 合并）。
 *   **上面的 C 函数名与签名一个都没变**，程序照旧写这些函数即可。
 * ⚠ 操作码是**跨语言契约，只能末尾追加**。程序一般不必直接碰它们。
 *
 * ⚠ 这一组原先**只有 `ui_audio_playing` 一个 C 出口** —— 播放 / 停止 / 调音量
 *   宿主里实现都在，却没写包装 ⇒ 22 门语言一个都调不到（死号）。v0.96.484 一并补齐。 */
#define VML_AUDIO_OP_PLAY       0   /* ui_audio_play   */
#define VML_AUDIO_OP_STOP       1   /* ui_audio_stop   */
#define VML_AUDIO_OP_VOLUME     2   /* ui_audio_volume */
#define VML_AUDIO_OP_IS_PLAYING 3   /* ui_audio_playing */
/* 复音发声（v0.96.485，**追加在末尾**）—— 上面四个是播放文件，下面三个是现场合成 */
#define VML_AUDIO_OP_NOTE_ON    4   /* ui_tone_on      */
#define VML_AUDIO_OP_NOTE_OFF   5   /* ui_tone_off     */
#define VML_AUDIO_OP_CONTROL    6   /* ui_tone_*（控制码见下） */

/* `ui_tone_*` 的控制码（与宿主 `VmlUi.AudioCtl` 同值，只能末尾追加） */
#define VML_TONE_CTL_ALL_OFF    0   /* ui_tone_all_off   */
#define VML_TONE_CTL_WAVE       1   /* ui_tone_wave      */
#define VML_TONE_CTL_MAX_VOICES 2   /* ui_tone_max_voices */
#define VML_TONE_CTL_VOICES     3   /* ui_tone_voices    */
#define VML_TONE_CTL_PANIC      4   /* ui_tone_panic     */

/* 波形（与 `VmlUi.ClampTone` 的 0..3 口径一致） */
#define VML_WAVE_SINE     0
#define VML_WAVE_SQUARE   1
#define VML_WAVE_SAW      2
#define VML_WAVE_TRIANGLE 3

/* 同时能响的声部上限 */
#define VML_TONE_MAX_VOICES 32

/* 播放一个音频文件（相对路径按沙箱根解）。`loop` 非 0 = 循环（BGM 用）。
   返回 0 成功 / -1 失败（文件不存在 / 路径非法 / 平台不支持）。 */
int  ui_audio_play(char* path, int loop);
/* 停掉正在播的音频。 */
void ui_audio_stop(void);
/* 设置整体音量（0–100，超出会被钳）。对**之后**播放的音生效。 */
void ui_audio_volume(int volume);
/* 后台 BGM 还在放吗 → 1/0（没放过、已放完、被停掉都是 0）。
 * 典型用法：等一首放完再进下一段 —— `while (ui_audio_playing()) { ... }`。 */
int  ui_audio_playing(void);

/* ── 复音发声（v0.96.485）────────────────────────────────────────────────
 *
 * 上面那四个是**播放文件**（BGM），这几个是**现场合成**（音符）。
 * 音符号是**真 MIDI 语义**：A4 = 69 = 440Hz、中央 C(do) = 60。
 *
 * ⚠ **复音 = 多个声部同时响**（最多 `VML_TONE_MAX_VOICES`）。
 *   `ui_beep` 那条"一次只发一个音"的老限制在这里**不存在**：
 *
 *       ui_tone_on(0, 60, 100);   // do
 *       ui_tone_on(1, 64, 100);   // mi
 *       ui_tone_on(2, 67, 100);   // sol   ← 三个音**同时在响**
 *       ...
 *       ui_tone_off(0, 60); ui_tone_off(1, 64); ui_tone_off(2, 67);
 *
 *   `ui_beep` 的老语义（连发只听见最后一个）**原样保留**，两者互不干扰
 *   —— 蜂鸣占一条自己的专用声道，不吃掉和弦里的任何声部。
 *
 * ⚠ 参数**一律钳、不拒**：越界的音符号会被钳到 0–127 继续响，而不是默默不发声。
 */

/* 起一个音。`ch` 通道 0–15、`note` 音符号 0–127、`vel` 力度 0–127（**0 等同关音**）。
   返回 0 成功 / -1 参数非法。 */
int  ui_tone_on(int ch, int note, int vel);

/* 关一个音。`note` 传 **-1** = 该通道上所有音。返回 0 成功 / -1 那个音本来就没在响。 */
int  ui_tone_off(int ch, int note);

/* 所有音走**淡出**（不是硬切 —— 硬切会"咔"）。 */
int  ui_tone_all_off(void);

/* 设通道的默认波形（`VML_WAVE_*`）。 */
int  ui_tone_wave(int ch, int wave);

/* 同时允许的声部上限（1–32）。 */
int  ui_tone_max_voices(int n);

/* 此刻在响的声部数（0–32）—— 查"和弦有没有真的叠起来"用它。 */
int  ui_tone_voices(void);

/* 立刻全停（**不进淡出**）。用于"用户强制停止 / 页面被销毁"这类场合。 */
int  ui_tone_panic(void);

/* ── 音效音序器（**不是 syscall**，是共享库里的一段状态机）──────────────
 *
 * 单靠 `ui_tone_on/off` 还做不出"听起来不是同一声哔"的音效，还差三件事：
 *
 *   ① `ui_tone_on` **没有时长参数** —— 响多久全看自己什么时候 `ui_tone_off`，
 *      忘了关，声部就只涨不落（上限 32，满了以后新音**全哑，而且不报错**）；
 *   ② 好听的音效是**几个音先后**（"叮—咚"、上行三音），而事件点只有一拍；
 *   ③ 同一个**通道**上后一个音会掐掉前一个 ⇒ "同时响"要落在不同通道上。
 *
 * 这一组把**机制**包了（一张 16 槽的表 + 每拍推进一次）；**音色留在各游戏里**
 * —— 哪个事件配什么音是设计，不是机制。
 *
 *      ui_sfx_add(3, 72, 0, 4, 95, VML_WAVE_SQUARE);   // do，立刻响 4 拍
 *      ui_sfx_add(4, 76, 1, 4, 85, VML_WAVE_SQUARE);   // mi，晚一拍起
 *      ui_sfx_add(5, 79, 2, 6, 85, VML_WAVE_SQUARE);   // sol
 *      ...
 *      ui_sfx_tick();                                   // 主循环里**每帧一次**
 *                                                       //   （它自己按真实流逝时间补拍）
 *
 * ⚠ `ui_sfx_tick` 放在**主循环**里，别挂在会被提前杀掉的定时器上 —— 一局结束那一刻
 *   物理定时器往往就被 kill 了，而胜负音正要开始放，结果**只响得出第一个音**
 *   （症状很像"音效没做"）。
 * ⚠ **通道按"谁与谁可能同拍"分区**（建议 0–2 爆炸 / 3–5 得分 / 6–7 发射 /
 *   8–9 空中 / 10–12 警报 / 13–15 胜负）：两个可能同时发生的音效共用通道时，
 *   后者把前者的槽顶掉，表现是**静默少一个音**。
 * ⚠ **低音别写太低**：手机外放在 200Hz 以下衰减很快，C2(65Hz) 出来是"噗"一声闷响，
 *   玩家听着像**没响**。轰鸣的基音落在 C3(130Hz) 上下比较稳。
 *
 * 完整的设计建议（哪种事件配什么音色）见 `docs/VML游戏开发指南.md` §4.5，
 * 可抄的例子见 `Examples/cpp/gorilla.cpp` 与 `Examples/basic/gorilla.bas`。 */

/* 清表（**不发声**）。⚠ 只清表不关音 = 已经在响的那些**从此没人管**。 */
void ui_sfx_reset(void);

/* 立刻静音：先把在响的全关掉、再清表（退出、这一局重开时用）。 */
void ui_sfx_panic(void);

/* 塞一个音：`delay` 拍之后开始响、响 `dur` 拍，走 `ch` 通道、`wave` 波形。
   ⚠ 会**先接管同通道的旧槽**（并把那个音关掉）。表满时静默丢弃（不越界）。 */
void ui_sfx_add(int ch, int note, int delay, int dur, int vel, int wave);

/* 每帧调一次：**按真实流逝时间自动补拍**（内部读 ui_tick()）。放在主循环里。 */
void ui_sfx_tick(void);

/* 手动推进**一拍** —— 一般不用它（`ui_sfx_tick` 已经替你补拍了），
   留给"自己的节拍就是基准、要手动控速"的场合。 */
void ui_sfx_step(void);

/* 表里还有几个槽占着（待响 + 在响）。**放完一轮应当回到 0** —— 拿它做自检的判据。 */
int  ui_sfx_active(void);

/* ── 蒙版 → 路径（描洞口的边）────────────────────────────────────────────
 *
 * 把当前蒙版的形状导出成 **SVG 路径字符串** —— 程序拿到它就能直接喂回 `ui_path`：
 * 画洞口的断面、做外发光，或者把洞的形状再拿去做别的运算。
 *
 *     int seg = ui_mask_seg_count();
 *     int i;
 *     if (seg >= 2 && ui_mask_seg_op(1) == VML_MASK_SUBTRACT) {   // 第 1 段是"被挖掉的洞"
 *         for (i = 0; i < ui_mask_shape_count(1); i++)
 *             if (ui_mask_path(1, i, buf, sizeof(buf)) > 0) {
 *                 ui_path(buf, 0x80000000, 2, 0, "", 1, 0);       // 描一圈暗边
 *             }
 *     }
 *
 * ⚠ 蒙版是"楼 − 洞"时，第 0 段是**底**（楼）、第 1 段起是**洞**（`SUBTRACT`）——
 *   要描洞口边就得按段取，光有形状列表是分不出"底还是洞"的。
 * ⚠ 圆导出的是**真圆弧**（`A` 命令），不是折线近似。
 * ⚠ 段与形状都按**当前蒙版**取 —— 下一条 `ui_mask_end*` 一执行就变了。
 */
int ui_mask_seg_count(void);                       /* 几段（没有蒙版返回 0）*/
int ui_mask_seg_op(int seg);                       /* 第 seg 段的运算符（越界 -1）*/
int ui_mask_shape_count(int seg);                  /* 第 seg 段几个形状（越界 0）*/
int ui_mask_path(int seg, int idx, char* buf, int cap);   /* 导出路径，返回字节数；放不下 -1 */
void ui_icon(int x, int y, char* name, int size, int color);
void ui_image(int x, int y, char* path, int w, int h);
void ui_present(void);

/* ── 像素读回（583–585）────────────────────────────────────────────────
 *
 * 场景是**保留模式**的（只有图元、没有像素缓冲），所以这三个号在宿主侧都会先
 * **光栅化一次**。老 graphics.h 程序要靠它们做填充与精灵。
 */

/* 从 (x,y) 灌色，**碰到 `border` 色就停**（四连通）。返回落笔的矩形条数，
   0 = 没填（种子点本身就在边界色上时是这样 —— 老程序「点在线上」很常见，不是错误）。 */
int ui_flood_fill(int x, int y, int color, int border);

/* 存一块画面 → **句柄**（≥1），失败 0。
   ⚠ 句柄由宿主保管，不是 VML 内存里的缓冲区（与 ui_brush/ui_gradient 同一套）。
   老程序的 `p = malloc(imagesize(...))` 照写不误，只是那块内存我们不用。 */
int ui_get_image(int x, int y, int w, int h);

/* 把句柄那块贴到 (x,y)。`mode`：0=COPY 直接贴 / 1=XOR 异或。返回 1 成功、0 失败。
   ⚠ XOR 必须**先读目的像素**（异或要拿它算），所以比 COPY 多一次光栅化 + 一次编码。 */
int ui_put_image(int x, int y, int handle, int mode);

/* 读一个像素的颜色 → **0xRRGGBB**（越界返回 -1）。异或擦除要用。
   ⚠ 每次调用宿主都要**光栅化一次**（场景是保留模式的），别放进密集大循环。 */
int ui_get_pixel(int x, int y);

/* ── 矢量图块（589，一个号 + 操作码）──────────────────────────────────
 *
 * **存的是绘图指令，不是像素。** 与上面 ui_get_image/ui_put_image 那对并存：
 *   像素路：w×h×4 字节，放大要重采样、转不了 —— 老程序的 GET/PUT 走它。
 *   矢量路：放大不糊、旋转免费、内存与图块尺寸无关 —— 新程序走这条。
 *
 * 用法：
 *     h = ui_create_block(32, 32, 0);
 *     ui_rect(0, 0, 32, 32, 0xFF0000, 1, 0, 0);
 *     ui_circle(16, 16, 8, 0xFFFFFF, 1, 0);
 *     ui_end_block();
 *     ui_draw_block(h, 200, 300, 1000, 1000, 45);    // 中心在(200,300)、原尺寸、转45°
 *     ui_draw_block_at(h, 10, 10, 2000, 1000, 0);    // 左上角在(10,10)、横向放大一倍
 *
 * 五条要知道的：
 *   ① **块内坐标以图块左上角为原点**（0,0 就是左上角）；
 *   ② `ui_draw_block` 的 (x,y) 是**中心**、绕中心转；`ui_draw_block_at` 是**左上角**、绕左上角转；
 *   ③ 缩放是**千分比**（1000 = 原尺寸），角度是**度**；
 *   ④ 块表**不随 ui_clear 清**（与匿名刷子同族）—— 造一次、之后一直贴；
 *      每帧 create 一遍会在 128 帧后拿不到句柄（那时 create 返回 0）；
 *   ⑤ 块里要用渐变/刷子，**就在 ui_create_block 之后建** —— 渐变定义行会随 ui_clear 清掉，
 *      而悬空引用是**静默退化成纯色**的（不报错、不记日志）。
 *
 * ⚠ **底层只有一个 syscall 号（589）**，`R0` 是操作码（下面这组宏）、参数从 `R1` 起。
 *   原先这里是 589–593 五个号（v0.96.481 合并）。**上面的 C 函数名与签名一个都没变**，
 *   程序照旧写这些函数即可 —— 操作码只是库内部的事。
 *   ⚠ 操作码是**跨语言契约，只能末尾追加**（与 VML_MSG_KIND_* 同族）。
 */

#define VML_BLOCK_CREATE   0   /* 开始录制 */
#define VML_BLOCK_END      1   /* 结束录制 */
#define VML_BLOCK_DRAW     2   /* 贴块，(x,y) 是中心 */
#define VML_BLOCK_DRAW_AT  3   /* 贴块，(x,y) 是左上角 */
#define VML_BLOCK_FREE     4   /* 释放句柄 */

/* 开始录一个图块。`w`/`h` 是尺寸声明（`ui_draw_block` 要用它算中心）；
   `color` 是**保留位** —— 图块永远**透明叠加**，传什么都没有区别。
   返回句柄（≥1）；0 = 失败（已经在录了 / 块表满 128）。 */
int ui_create_block(int w, int h, int color);

/* 结束录制。返回句柄（与 ui_create_block 给的那个一致）；0 = 没在录制。 */
int ui_end_block(void);

/* 贴图块：**(x,y) 是图块中心，绕中心旋转**。
   `sx`/`sy` 千分比（1000 = 原尺寸），`rot` 度。返回 1 成功 / 0 失败。 */
int ui_draw_block(int block, int x, int y, int sx, int sy, int rot);

/* 同上，但 **(x,y) 是图块左上角、绕左上角旋转**。 */
int ui_draw_block_at(int block, int x, int y, int sx, int sy, int rot);

/* 释放一个图块，返回 1 成功 / 0 失败（句柄不存在或已释放）。
   ⚠ **块表有 128 的上限，而"改一个块的内容"只能重录新块**（块的内容与尺寸都不可变），
     所以凡是"内容会变"的用法都必须先释放旧的 —— 不释放就是每重录一次漏一个句柄，
     迟早撑满，之后 `ui_create_block` 一律返回 0（画面**悄悄**退回逐帧画，看不出"块没了"）。
   ⚠ 释放过的句柄会被**回收复用**，所以别在别处留着旧句柄当"以后再贴"；
     贴一个已失效的句柄是**静默 no-op**。 */
int ui_free_block(int block);

/* ── 主动截屏（588）────────────────────────────────────────────────────
 *
 * 把**画布**存成一张 PNG 文件。与上面三个的分工：那几个是给程序在运行中
 * 读像素用的（句柄 / 单点），这个是把整幅画面存下来给用户看。
 */

/* 把当前画布存成 PNG，写进 `path`。返回写入的字节数，-1 = 失败（不区分原因）。
 *
 * `path` 是**相对沙箱的路径**；没有扩展名就补 `.png`，子目录会自动建。
 * **空串 = 自动命名**：落在 `shot/` 下，名字是 `<窗口标题>_<日期>_<时间>.png`
 *（如 `shot/五子棋_20260924_102801.png`）—— 省得程序自己拼名字，
 * 而且带时间戳不会互相覆盖。想自己命名就直接给路径。
 *
 * ⚠ 不许出现 `..`、`.` 段与盘符/scheme —— 含了就直接 -1
 *（这是防写到你沙箱外面的唯一一道闸），一个字节都不会落到盘上。
 * ⚠ 存的是**画面本身**，不含屏幕手柄与标题栏（当战绩图/分享图用，干净的画面更好）。
 *   实现走共享光栅器，四端同一份代码，不依赖任何平台截屏 API 与权限。
 * ⚠ 会阻塞几十毫秒（光栅化 + 编码 PNG）⇒ 别放进每帧的循环里。
 * ⚠ 失败也可能是"还没有画布"（窗口没开），返回 -1 与路径非法同码，别只当路径写错。 */
int ui_screenshot(char* path);

/* ── 文字 ── */
/* ⚠ `ui_text` 会**显式把样式位置 0**（常规）。
   曾经不是这样，于是有个很难查的 bug：程序先 `ui_rect(..., 线宽, 圆角)`（线宽落在 R6），
   再 `ui_text(...)`，残留的线宽就被当成样式位 ⇒ **之后的文字随机变粗/变斜**。
   要粗/斜请用下面的 `ui_text_styled`（它显式给第 7 个参数）。 */
void ui_text(int x, int y, char* s, int color, int size, int anchor);
void ui_text_styled(int x, int y, char* s, int color, int size, int anchor, int style);
/* 带**竖对齐**的文字（新号 #581）—— valign 见 VML_VANCHOR_*，style 见 VML_FONT_*。
 * ⚠ 与 `ui_text_styled` **参数序不同**（那个第 7 个是 style），别互相照抄。 */
void ui_text_v(int x, int y, char* s, int color, int size, int anchor, int valign, int style);
void ui_set_font(int size, int style, int color, int anchor);
/* 设"当前文字"的**竖对齐**（状态式，配 ui_text_cur 用）：VML_VANCHOR_TOP/MIDDLE/BOTTOM/BASE。
   ⚠ 是**新号 #586**，没有并进 ui_set_font —— 给老 syscall 加参数会让只传前几个参数的
     老程序读到自己上一句留下的垃圾值（宿主没法判断"这是不是真给了"）。 */
void ui_set_valign(int valign);
void ui_text_cur(int x, int y, char* s);

/* ── 全能接口（#573）：两个字符串进、一个 JSON 字符串出 ──
 *
 * 给**不要求性能**的可扩展功能用：加一个能力 = 宿主侧注册一个函数，不占 syscall 号、
 * 不用重生成各语言绑定。绘图/输入这类每帧都发生的调用**别走这里**。
 *
 * 结果永远是对象：成功 {"ok":true,"result":…}，失败 {"ok":false,"error":"…"}。
 * 宿主侧已注册：echo（原样回显，自检用）/ version（App 名与版本）/ screen（可用绘图区
 * 与控制方向，与 SCR_W/H/SCR_ORIENT 同源）。 */
int  ui_call_json(char* fn, char* args_json, char* out_buf, int cap);
/* 拿不到缓冲区指针的前端用这两个：结果进静态缓冲，按字节读。 */
int  ui_call_json_s(char* fn, char* args_json);
int  ui_call_json_len(void);
int  ui_call_json_at(int i);
/* 把上一次 ui_call_json_s 的结果整份打到 stdout（末尾补换行）。
   22 种语言的自测都靠它把结果原样打出来，省得各自写一遍"逐字节取 + 单字符输出"。 */
void ui_call_json_print(void);
/* fn 是函数名、args_json 是参数（可为 "" 或 0）。例：
     char buf[256];
     ui_call_json("screen", "", buf, 256);      // {"ok":true,"result":{"w":395,…}}
     ui_call_json("echo", "{\"n\":7}", buf, 256); */

/* ── 不碰指针的消息读取 + 通用整数网格（非 C 语言用，C 也能用）── */
int  ui_wait_msg(int timeout_ms);
int  ui_poll_msg(void);
int  ui_msg_type(void);
int  ui_msg_a(void);
int  ui_msg_b(void);
void ui_gclear(void);
void ui_piece_init(void);
int  ui_piece_cell(int pid, int rot, int which);
void ui_gset(int idx, int val);
int  ui_gget(int idx);

/* ── 输入 ──
 *
 * ⚠ **底层只有一个 syscall 号（560）**：`R0` 是操作码（下面这组宏）、参数从 `R1` 起。
 *   原先这里是 560/561/562/568/571/572/596 **七个号**（v0.96.483 合并）——
 *   宿主侧 `Poll`/`Wait` 本来就是同一份实现、只差一个保留位。
 *   **下面这些 C 函数名与签名一个都没变**，程序照旧写它们即可 —— 操作码只是库内部的事。
 * ⚠ 操作码是**跨语言契约，只能末尾追加**。程序一般不必直接碰它们。 */
#define VML_MSG_OP_POLL     0   /* ui_poll      */
#define VML_MSG_OP_WAIT     1   /* ui_wait      */
#define VML_MSG_OP_COUNT    2   /* ui_msg_count */
#define VML_MSG_OP_CLEAR    3   /* ui_msg_clear */
#define VML_MSG_OP_DROP     4   /* ui_msg_drop  */
#define VML_MSG_OP_POLL_EX  5   /* ui_poll_ex   */
#define VML_MSG_OP_WAIT_EX  6   /* ui_wait_ex   */

int  ui_poll(int* msg);
int  ui_wait(int* msg, int timeout_ms);
/* 读一条，带"读完之后留不留"：keep=VML_MSG_KEEP 时**只看队头、不取走**
   （下一次读到的还是它，直到明确消费掉）；VML_MSG_CONSUME 与 ui_poll/ui_wait 同义。
   ⚠ 保留模式**别当循环条件用** —— 它永远返回同一条。 */
int  ui_poll_ex(int* msg, int keep);
int  ui_wait_ex(int* msg, int timeout_ms, int keep);
#define VML_MSG_CONSUME 0
#define VML_MSG_KEEP    1
int  ui_msg_count(void);
/* 丢掉队列里所有待处理消息 → 丢弃条数。重新开始/切关时调，
   防上一局没读完的输入（一次点击常有多条）被新一局读出来。 */
int  ui_msg_clear(void);

/* 消息类别 —— `ui_msg_drop(kind)` 的 kind（**跨语言契约**，与宿主的 `VmlMsgKind` 同值）。
   ⚠ 只能末尾追加：数值会编进程序里。 */
#define VML_MSG_KIND_TIMER 0   /* 定时器消息（ui_timer_kill 是"停表"，这个是"清掉已排队的到点通知"） */
#define VML_MSG_KIND_TOUCH 1   /* 触摸：按下 / 移动 / 抬起 */
#define VML_MSG_KIND_MOUSE 2   /* 鼠标：移动 / 按下 / 抬起 */
#define VML_MSG_KIND_KEY   3   /* 键盘：按下 / 抬起 */
#define VML_MSG_KIND_ALL   4   /* 全部（等价于 ui_msg_clear，只是回报条数） */

/* 丢掉队列里**某一类**还没被消费的消息 → 丢掉的条数（-1 = 类别认不出，什么也没丢）。
 *
 * 用于"移动类消息积压"：它是**追最新位置**的语义，旧的位置没有价值，而主循环
 * 一次只取一条 ⇒ 拖动时产生的比消费的快，队列只涨不落（实测 6 轮涨到 2280 条），
 * 触摸事件于是排在队尾 —— 表现为"背景绘图不卡、但触摸要等半天才反应"。
 * 在 TOUCHMOVE 分支里调一次 `ui_msg_drop(VML_MSG_KIND_TOUCH)` 即可让队列回到个位数。
 *
 * ⚠ **别拿它丢键盘 / 定时器**：那两类是离散语义，丢一条就少一次事件。 */
int  ui_msg_drop(int kind);

/* 定时器 —— 底层同样只有一个号（563）+ 操作码（v0.96.483 合并，原先 563/564 两个号）。 */
#define VML_TIMER_OP_SET   0   /* ui_timer_set  */
#define VML_TIMER_OP_KILL  1   /* ui_timer_kill */

int  ui_timer_set(int interval_ms, int tag);
int  ui_timer_kill(int timerId);

/* ── 绘图增强（534–539，v0.96.176）：渐变刷子 / 路径与曲线 / 多边形 ──
 *
 * 这一组也是**本地加的**，同样要提给上游 VML 仓库（理由见文件末尾那段）。
 * 坐标与颜色约定与既有绘图接口一致（dp、0xAARRGGBB）。 */

/* 渐变刷子：id 之后用 ui_rect_grad / ui_circle_grad / ui_path 的 grad 参数按名引用。
 * 几何是**归一化 0..1000 的整数**（千分之一）：线性给 x1,y1,x2,y2；径向给 cx,cy,r（第 4 个忽略）。
 * 不想要自定义几何就传 0,0,1000,0（线性从左到右）或 500,500,500,0（径向居中）。 */
void ui_gradient(char* gradId, int radial, int color_a, int color_b,
                 int a1, int a2, int a3, int a4);

/* 路径：d 是 **SVG path 语法**（M L H V C S Q T A Z，大小写区分绝对/相对）。
 * stroke=描边色（0=不描边）、width=线宽、fill=填充色（0=不填充）、
 * grad=渐变 id（非 0 时用它填充、忽略 fill）、cap=0平/1圆/2方、dash=0/1 虚线。 */
void ui_path(char* d, int stroke, int width, int fill, char* grad, int cap, int dash);

/* 多边形（自动闭合）/ 折线：pts 是 int 数组，**每两个 int 一个点**（x,y）；count 是**点数**。 */
void ui_polygon(int* pts, int count, int fill, int stroke, int width, char* grad);
void ui_polyline(int* pts, int count, int stroke, int width, char* grad);

/* 渐变填充的矩形 / 圆（渐变按钮、渐变背景这类最常用） */
void ui_rect_grad(int x, int y, int w, int h, char* grad, int radius);
void ui_circle_grad(int cx, int cy, int r, char* grad);

/* ── 刷子 / 样式 / 形状（574–576）────────────────────────────────────
 *
 * 一条总原则：**颜色 = 只有一个色标的刷子** —— `ui_set_fill(0xFF2A3346)` 直接
 * 传颜色是合法的，不必先 `ui_brush_solid` 一下。
 *
 * 旧的 `ui_rect` / `ui_circle` / … **全部原样保留**（各走各的老号）；这一套是另加的：
 * 样式来自"当前刷子"，绘制调用本身**不带颜色**。
 *
 * ⚠ 本批**画笔与文字只支持纯色**：渐变描边/渐变文字要等引擎侧做出来。
 *   给渐变句柄时宿主会记一次警告并退回该渐变的起始色（不静默）。 */
int  ui_brush_solid(int color);
int  ui_brush_linear(int color_a, int color_b, int x1, int y1, int x2, int y2);
int  ui_brush_radial(int color_a, int color_b, int cx, int cy, int r);
int  ui_brush_named(char* gradId);
int  ui_set_fill(int brush);
int  ui_set_pen(int brush, int width, int cap, int dash, int arrow);
int  ui_set_text_brush(int brush);

void ui_draw_rect(int x, int y, int w, int h, int radius);
void ui_draw_circle(int cx, int cy, int r);
void ui_draw_ellipse(int cx, int cy, int rx, int ry);
void ui_draw_line(int x1, int y1, int x2, int y2);
void ui_draw_poly(int* pts, int count, int close);
void ui_draw_path(char* d);
void ui_draw_text(int x, int y, char* s);
void ui_draw_star(int cx, int cy, int r_out, int r_in, int points, int rot);
void ui_draw_regular(int cx, int cy, int r, int n, int rot);
void ui_draw_ring(int cx, int cy, int r_out, int r_in);
void ui_draw_pie(int cx, int cy, int r, int a0, int a1);
void ui_draw_heart(int cx, int cy, int size);
void ui_ellipse_grad(int cx, int cy, int rx, int ry, char* grad);

/* ui_set_pen 的线帽 */
#define VML_CAP_BUTT    0
#define VML_CAP_ROUND   1
#define VML_CAP_SQUARE  2
/* ui_set_pen 的箭头。⚠ 本批只做**末端**箭头，且只对 ui_draw_line 生效
 *   （折线/路径的箭头要各自的几何支持，还没做）—— START/BOTH 与 END 同义 */
#define VML_ARROW_NONE  0
#define VML_ARROW_END   1
#define VML_ARROW_START 2
#define VML_ARROW_BOTH  3

/* ── 随机数 / 计时（游戏用；实现走 VM 的 #50/#53，各语言共用一份）── */
int  ui_rand(int n);      /* 0..n-1 */
int  ui_tick(void);       /* VM 启动至今毫秒 */

/* ── 手感：音效 / 震动 / 持久化 / 常亮 ──
   音效走 **VM 内置的 #57 蜂鸣**（宿主把它接到真实音频，零素材、不必打包音频文件）。
   这一组同样要提给上游 VML 仓库（Lib/ 会被 sync.sh 覆盖）。 */
void ui_beep(int freq, int ms);              /* 合成音：频率 Hz + 时长 ms */
/* 震动 —— 底层只有一个号（545）+ 操作码（v0.96.484 合并，原先 545/546 两个号）。 */
#define VML_VIBRATE_OP_SIMPLE   0   /* ui_vibrate        */
#define VML_VIBRATE_OP_PATTERN  1   /* ui_vibrate_pattern */

void ui_vibrate(int ms, int strength);         /* 震动一下（Android 需 VIBRATE 权限，normal 级） */
/* 按节奏震动：`pattern` 是 int 数组（奇数下标=静、偶数下标=动，同 Android 语义），
   `count` 段数（最多 VML_VIBRATE_MAX_SEGMENTS）。返回 0 成功 / -1 失败。 */
int  ui_vibrate_pattern(int* pattern, int count);

void ui_keep_on(int on);                     /* 玩游戏时别熄屏：0 关 / 1 开 */

/* 持久化 —— 底层只有一个号（550）+ 操作码（v0.96.484 合并，原先 550/551/552 三个号）。
   键由宿主统一加 `vml.` 前缀，不会和 App 自己的设置打架。 */
#define VML_STORE_OP_SET     0   /* ui_store_set */
#define VML_STORE_OP_GET     1   /* ui_store_get */
#define VML_STORE_OP_DELETE  2   /* ui_store_del */

void ui_store_set(char* key, char* value);   /* 写持久化键值（最高分/进度/设置） */
int  ui_store_get(char* key, char* buf, int cap);  /* 读；返回长度，没有这条键返回 -1 */
/* 删掉一条存档（句柄回收式的清理，例如"清空最高分"）。返回 0 成功 / -1 失败（键非法）。 */
int  ui_store_del(char* key);

/* ── 命令行参数 ──
   参数由宿主喂（桌面 `vmlcli prog.c --arg -l`、手机 `vml run prog.c -l`）。
   `argv[0]` 是程序名、恒存在 ⇒ 用户给的第一个参数是 `ui_arg(1,…)`。
   ⚠ `int main(int argc, char **argv)` 的程序**不需要**它们（入口帧直接给），
      这两个是给 `int main(void)` 的程序和非 C 语言绑定用的。 */
int  ui_argc(void);                          /* 参数个数（含程序名，恒 ≥ 1） */
int  ui_arg(int i, char* buf, int cap);      /* 拷第 i 个进 buf；返回长度，越界 -1 */

/* ── 通用宿主调用口（577–580，v0.96.326）──────────────────────────────
 *
 * 这四个函数让程序**按数字 id 调宿主的函数**：参数直接躺在寄存器里、返回值直接
 * 写回第 0 号寄存器，**一次调用零编解码**（对比 `ui_call_json` —— 那条路要
 * 序列化 + 解析两趟 JSON，好处是加能力不用占号）。
 *
 * 用法（四步）：
 *
 *     int v[8];
 *     v[0] = VML_CALL_ECHO_INT;   ① 调用号，见下面的宏
 *     v[1] = 1; v[2] = 2; …       ② 参数（不够的位留 0）
 *     int r = callwithint8(v);    ③ 发出去，返回值覆盖 v[0] —— ④ **拿不到原来的 v[0]**
 *
 * ## 寄存器约定（跨语言契约，改不得）
 *
 *     callwithint8  : v[0..7] → R0..R7   返回值 → R0
 *     callwithfloat8: v[0..7] → F0..F7   返回值 → F0
 *     callwithlong4 : v[0..3] → L0..L3   返回值 → L0
 *     callwithdouble4: v[0..3] → D0..D3  返回值 → D0
 *
 * 第 0 个元素**既是调用号（进）又是返回值（出）** —— 所以"调用方拿不到 val[0]"
 * 是设计的一部分，不是缺陷。四个函数的调用号都是 `(int)v[0]`
 * （float 那个也一样：调用号必须能被 `float` 精确表示，id < 2²⁴ 就安全）。
 *
 * ## 失败长什么样
 *
 * **不崩**。没注册过的 id、种类对不上、实现体自己抛异常，都写回一个**负数失败码**：
 * `-2` 参数非法、`-6` 没有这个调用号、`-9` 宿主内部错误（正数才是正常返回值）。
 * 宿主同时会记一条可读日志。
 *
 * ## 实现与注册
 *
 * 实现在 `Lib/shared/src/vmlui.c`（编成 `.vml` 后各语言共用），
 * 调用号 → 函数的对应表在宿主里（手机 `WayCoder.Maui/Services/VmlUiCalls.cs`、
 * 桌面 `scripts/vmlcli`，两边共用 `WayCoder/UI/Shared/VmlCallRegistry.cs`）。
 */
int    callwithint8(int* v);
float  callwithfloat8(float* v);
long   callwithlong4(long* v);
double callwithdouble4(double* v);

/* 调用号 —— **跨语言契约，只能末尾追加、不能改值**。
 * 本批是"自检族"：返回值是每个参数按位权拼出来的可分辨数
 * （传 1,2,3,4,5,6,7 得 7654321），哪个参数没到、串没串位一眼看得出。 */
#define VML_CALL_ECHO_INT     1   /* callwithint8：7 个 int 的位权拼接 */
#define VML_CALL_ECHO_FLOAT   2   /* callwithfloat8：同上，浮点域 */
#define VML_CALL_ECHO_LONG    3   /* callwithlong4：3 个 long 的位权拼接（×1 / ×1000 / ×10⁶） */
#define VML_CALL_ECHO_DOUBLE  4   /* callwithdouble4：同上，浮点域 */
#define VML_CALL_HOST_INFO    5   /* callwithint8：宿主种类（VML_CALL_HOST_*） */

/* VML_CALL_HOST_INFO 的返回值 */
#define VML_CALL_HOST_DESKTOP 1   /* 桌面脚手架（scripts/vmlcli） */
#define VML_CALL_HOST_MOBILE  2   /* 手机 App */

#endif /* WAYCODER_UI_H */
