/* vmlui.c —— 手机端 UI syscall 的**共享调用库**（对话框 / 窗体 / 绘图 / 输入）
 *
 * 编译：`Lib/build_libs.sh --shared`（等价于
 *       `vmltool -c vmlui.c -o ../vmlui.vml -I ../shared -I ../c --mode mcu --no-link`）
 * 产物：`Lib/shared/vmlui.vml` —— 由 `vmltool.config.xml` 挂到各语言的 `Libs` 上，
 *       **C 与 Python 等前端共用同一份实现**。
 *
 * ## 为什么要有这个文件（而不是让各语言自己写）
 *
 * 汇编级 syscall 只有 C/ObjC/C++ 能直接调（`asm()`），其余前端（Python/BASIC/…）
 * 只能**按标签调用 C 函数**。所以"让所有语言都能用上 UI 接口"的唯一做法，
 * 就是在这里写一层 C 包装、编成 `.vml` 供大家链接 —— 这正是上游 `Lib/shared/src/vmlsys.c`
 * 的定位（它给非 C 语言提供类型安全的 SYSCALL 接口）。
 *
 * ⚠ **上游那份 `vmlsys.c` 的参数传递是坏的**：里面写成
 * `void vml_print_int(int n) { asm("SYSCALL 6"); }` —— **没有把 n 放进 R0**，
 * 而 `asm()` 的文本是原样进汇编器的，汇编器并不认识 C 的形参名。
 * 本文件用 `${形参}` 占位符（C 前端唯一实现了的替换），形参按出现顺序自动落
 * R0、R1、R2…，所以参数是真的传进去了（详见 `Lib/README-ui.md` 的实测校准）。
 *
 * ## 返回值
 *
 * 形如 `return asm("SYSCALL #566");` —— **必须把 asm 当表达式用**；
 * 写成"先 asm(...) 再 return 0"会把返回值丢掉。
 *
 * ## 线程/生命周期
 *
 * 这些函数只做"把参数量进寄存器 + 发一条 syscall"，状态全在宿主侧
 * （`WayCoder.Maui/Services/VmlUiCalls.cs`）。没有全局变量，可重入。
 */

/* ── 对话框 ─────────────────────────────────────────────── */

/* 消息框。返回 0=确定/是，1=否/取消。 */
int ui_dlg_msg(char* title, char* body, int style) {
    return asm("SYSCALL #500, ${title}, ${body}, ${style}");
}

/* 单选。opts 是 NUL 分隔的选项块，n=选项数，def=默认项。返回选中下标，取消 -1。 */
int ui_dlg_select(char* title, char* body, char* opts, int n, int def) {
    return asm("SYSCALL #501, ${title}, ${body}, ${opts}, ${n}, ${def}");
}

/* 多选。返回位掩码（第 i 项 = 1<<i），取消 -1。 */
int ui_dlg_multi(char* title, char* body, char* opts, int n) {
    return asm("SYSCALL #502, ${title}, ${body}, ${opts}, ${n}");
}

/* 输入框：把用户输入写进 buf（最多 cap-1 字节 + 结尾 NUL）。返回写入长度，取消 -1。 */
int ui_dlg_input(char* title, char* prompt, char* buf, int cap) {
    return asm("SYSCALL #503, ${title}, ${prompt}, ${buf}, ${cap}");
}

/* ── 窗体 ───────────────────────────────────────────────── */

/* 开一个绘图窗口（带标题栏与返回箭头）。返回句柄(1)，失败 -1。 */
int ui_win_open(char* title, int w, int h) {
    return asm("SYSCALL #520, ${title}, ${w}, ${h}");
}

/* 开窗（带声明）。rotatable 三选一：VML_WIN_PORTRAIT 只竖屏 / VML_WIN_ROTATABLE 支持旋转 /
 * VML_WIN_LANDSCAPE 只横屏；gamepad=0 ⇒ 不显示屏幕手柄区，画布吃满整屏。
 * 老程序照旧用 ui_win_open()（走 #520）—— **两个号各调各的，默认值只有宿主一处**：
 * 老号那边宿主直接给"可旋转=1、要手柄=1"，在这里再写一遍默认值就是第二张平行表。 */
int ui_win_open_ex(char* title, int w, int h, int rotatable, int gamepad) {
    return asm("SYSCALL #570, ${title}, ${w}, ${h}, ${rotatable}, ${gamepad}");
}

/* 开**电脑屏窗口**（第三种窗口，给老程序用）。
 *
 * 与 ui_win_open_ex 的差别是**三件事**，都在宿主那侧表达：
 *   ① 坐标系**固定**为 (w,h)，**永不**跟随旋转重排 —— 老程序按固定分辨率排的版，
 *      换空间就会画到框外。所以这里的 rotatable **没有"支持旋转"那一档**，
 *      它只决定**锁不锁方向**：PORTRAIT 锁竖 / LANDSCAPE 锁横 / 其它 = 不锁。
 *   ② 触摸**只发鼠标消息**（不发触摸消息）—— 老程序处理的是鼠标。
 *   ③ 带**屏幕键盘**（PC 布局）而不是手柄区；keyboard=0 可以关掉它吃满整屏。
 *
 * 画图照旧走 ui_*（`ui_clear`/`ui_rect`/`ui_line`/`ui_text`…）——
 * **不碰显存**，那是另一套已经不做的东西。
 *
 * ⚠ 默认分辨率 640×480（PC 上最眼熟那一档）由**宿主**兜底，这里不写第二遍。 */
int ui_win_open_pc(char* title, int w, int h, int rotatable, int keyboard) {
    return asm("SYSCALL #582, ${title}, ${w}, ${h}, ${rotatable}, ${keyboard}");
}

int ui_win_close(void) {
    return asm("SYSCALL #521");
}

/* 用户点了返回箭头 → 1，程序主循环应退出。 */
int ui_win_closed(void) {
    return asm("SYSCALL #565");
}

/* 可用绘图区（单位与绘图一致，可直接拿来算格子）。 */
int ui_scr_w(void) {
    return asm("SYSCALL #566");
}

int ui_scr_h(void) {
    return asm("SYSCALL #567");
}

/* 屏幕方向：0 = 竖屏，1 = 横屏。开窗之前就能问。
   别拿 ui_scr_w() > ui_scr_h() 去推：那是**绘图区**的形状，会随宿主排版变
   （手柄收起/展开就变），而方向是设备本身的属性。 */
int ui_orientation(void) {
    return asm("SYSCALL #569");
}

/* ── 绘图（保留模式：只管追加图元，宿主按帧渲染）───────────── */

void ui_clear(int color) {
    asm("SYSCALL #522, ${color}");
}

void ui_pixel(int x, int y, int color) {
    asm("SYSCALL #523, ${x}, ${y}, ${color}");
}

void ui_line(int x1, int y1, int x2, int y2, int color, int lw) {
    asm("SYSCALL #524, ${x1}, ${y1}, ${x2}, ${y2}, ${color}, ${lw}");
}

/* fill!=0 画实心；radius>0 画圆角。 */
void ui_rect(int x, int y, int w, int h, int color, int fill, int lw, int radius) {
    asm("SYSCALL #525, ${x}, ${y}, ${w}, ${h}, ${color}, ${fill}, ${lw}, ${radius}");
}

void ui_circle(int cx, int cy, int r, int color, int fill, int lw) {
    asm("SYSCALL #526, ${cx}, ${cy}, ${r}, ${color}, ${fill}, ${lw}");
}

void ui_ellipse(int cx, int cy, int rx, int ry, int color, int fill, int lw) {
    asm("SYSCALL #527, ${cx}, ${cy}, ${rx}, ${ry}, ${color}, ${fill}, ${lw}");
}

/* ── 绘图状态（`ui_gfx`，SYSCALL #595）────────────────────────────────────
 *
 * 三个操作走**同一个号**，第一个参数是操作码 —— 理由见 `waycoder_ui.h` 的说明
 * （号段不够）。返回值是宿主的应答：1 = 认了，0 = 不认识这个操作码。
 *
 * ⚠ 用 `return asm(...)` 而不是先 asm 再 return 一个变量 ——
 *   后者会把 syscall 的返回值整个丢掉（本仓记过这条：`io.c` 的 `getchar` 就是这么坏的）。
 */
/* ⚠⚠ **asm 串里的字面量参数会被整个丢掉**（实测）：写成
 *      asm("SYSCALL #595, 0, ${x}, ${y}, ${w}, ${h}")
 *    编出来是 `R0=x, R1=y, R2=w, R3=h` —— 那个 `0` 凭空消失，**参数整体前移一格**；
 *    而 `ui_clip_pop` 那种"全是字面量"的更是**一条寄存器装载都没有**，直接 `syscall`。
 *    ⇒ 所有实参（含操作码）一律写成 `${变量}`。这与 `ui_rect`/`ui_circle` 那批
 *      包装函数的写法一致 —— 它们的形参本来就全是 `${}`，所以从来没踩到。
 *    这条已记进 `VMLPrepares/CCompiler/KNOWN_DEFECTS.md`。
 */
int ui_clip_push(int x, int y, int w, int h) {
    int op;
    op = 0;
    return asm("SYSCALL #595, ${op}, ${x}, ${y}, ${w}, ${h}");
}

int ui_clip_pop(void) {
    int op;
    int z;
    op = 1;
    z = 0;
    /* ⚠ 操作码与占位参数**都必须写成 `${}` 变量**，不能写字面量 —— 见文件开头那条说明。 */
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

int ui_alpha(int v) {
    int op;
    int z;
    op = 2;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${v}, ${z}, ${z}, ${z}");
}

int ui_brush_reset(void) {
    int op;
    int z;
    op = 8;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

int ui_clip_reset(void) {
    int op;
    int z;
    op = 9;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

int ui_mask_begin(void) {
    int op;
    int z;
    op = 3;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

int ui_mask_end(int inside) {
    int op;
    int z;
    op = 4;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${inside}, ${z}, ${z}, ${z}");
}

/* 结束收集，并与**当前蒙版**按布尔运算符组合（op 取 `waycoder_ui.h` 的 VML_MASK_*）。
 * ⚠ 运算符用**新的操作码 11**，不是给 ui_mask_end 加参数 —— 宿主是从 registers[n] 读参数的，
 *   只传一个参数的老程序后面那几只寄存器里是它自己上一句留下的值，宿主无从判断"给没给"。
 *   与 `ui_mask_end` 的区别：这条**不动 inside**（保持当前值）。 */
int ui_mask_end2(int op) {
    int code;
    int z;
    code = 11;
    z = 0;
    return asm("SYSCALL #595, ${code}, ${op}, ${z}, ${z}, ${z}");
}

int ui_mask_clear(void) {
    int op;
    int z;
    op = 5;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

/* 查一点在不在当前蒙版里（详见 `waycoder_ui.h`）—— 蒙版当碰撞体用。 */
int ui_mask_test(int x, int y) {
    int op;
    int z;
    op = 12;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${x}, ${y}, ${z}, ${z}");
}

/* 当前蒙版有几段 / 第 seg 段的运算符 / 第 seg 段有几个形状。 */
int ui_mask_seg_count(void) {
    int op;
    int z;
    op = 13;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

int ui_mask_seg_op(int seg) {
    int op;
    int z;
    op = 16;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${seg}, ${z}, ${z}, ${z}");
}

int ui_mask_shape_count(int seg) {
    int op;
    int z;
    op = 14;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${seg}, ${z}, ${z}, ${z}");
}

/* 把第 seg 段第 idx 个形状导出成 SVG 路径，写进 buf（容量 cap）。返回写入字节数，放不下 -1。 */
int ui_mask_path(int seg, int idx, char* buf, int cap) {
    int op;
    int z;
    op = 15;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${seg}, ${idx}, ${buf}, ${cap}");
}

int ui_res_count(int what) {
    int op;
    int z;
    op = 10;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${what}, ${z}, ${z}, ${z}");
}

/* 图层（离屏合成）：`layer_begin … layer_end(alpha)` 之间的图元先画进临时画布，
 * 收尾时**整层**按 alpha（0..255）合成上去。详见 `waycoder_ui.h`。 */
int ui_layer_begin(void) {
    int op;
    int z;
    op = 6;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${z}, ${z}, ${z}, ${z}");
}

int ui_layer_end(int alpha) {
    int op;
    int z;
    op = 7;
    z = 0;
    return asm("SYSCALL #595, ${op}, ${alpha}, ${z}, ${z}, ${z}");
}

/* ── 手机特有的操作方式（#556–559 / #547）────────────────────────────────
 *
 * ⚠ 这几条**各有各的号**，不是 `ui_gfx` 的操作码。
 */
int ui_touch(int slot, int* out) {
    return asm("SYSCALL #556, ${slot}, ${out}");
}

/* 面向**不支持指针的语言**（Python/BASIC/…）的取触摸接口 —— 与
 * `ui_wait_msg` + `ui_msg_a/b` 是同一套分工（那边也是"取一条，拆开放静态变量"）：
 *
 *     ui_touch_query(0);
 *     x = ui_touch_x();  y = ui_touch_y();  if ui_touch_down(): ...
 *
 * ⚠ 一次只保留**最近一次查询**的结果（单缓冲），与消息那几个访问器同一口径。
 */
static int _ui_touch_x;
static int _ui_touch_y;
static int _ui_touch_down;

int ui_touch_query(int slot) {
    int tmp[3];
    int ok;
    tmp[0] = 0; tmp[1] = 0; tmp[2] = 0;
    ok = ui_touch(slot, tmp);
    _ui_touch_x = tmp[0];
    _ui_touch_y = tmp[1];
    _ui_touch_down = tmp[2];
    return ok;
}

int ui_touch_x(void) { return _ui_touch_x; }
int ui_touch_y(void) { return _ui_touch_y; }
int ui_touch_down(void) { return _ui_touch_down; }

int ui_key_down(int key) {
    return asm("SYSCALL #557, ${key}");
}

/* ── 传感器（`SENSOR` #554，v0.96.492）────────────────────────────────────
 *
 * 一个号 + 操作码：`R0`=操作码 `R1`=种类（0 加速度 / 1 角速度 / 2 融合姿态）。
 *
 * **游戏里该怎么选**（这是这段最该看的一句）：
 *   · 做**倾斜控制**（"把手机歪向哪边、角色就往哪边走"）用 **`VML_SENS_ACCEL`** ——
 *     静止时它读到的是重力方向，**不漂移**，而且几乎所有设备都有。
 *   · 要**瞬时动作**（"甩一下"）用 `VML_SENS_GYRO` —— 它是角速度，
 *     想拿"当前角度"得自己积分，而**积分会漂**（几十秒就偏出可用范围）。
 *   · 要**精确且长时间稳定的角度**用 `VML_SENS_ROTATION`（平台融合好的欧拉角）。
 *     代价是**有的设备没有**（没磁力计时方位角会慢慢转），先问 `ui_sensor_available`。
 *
 * 单位是**整数定标**（不是浮点）：加速度 **毫克**（1000 = 1g）、
 * 角速度 **千分之一度/秒**、姿态角 **千分之一度**。理由与图元的"千分比"一样：
 * 整数让 ABI 不必管浮点寄存器，精度也够（手机满量程约 ±2000°/s ⇒ 定标后约 ±200 万）。
 *
 * ⚠ 与触摸一样是**轮询式**：姿态是连续量，一秒钟几十个采样，投消息只会把队列淹掉。
 *   程序每帧自己查（`ui_sensor` 很轻，但**别放进逐像素循环**）。
 * ⚠ **没有传感器的设备要能分辨**：`ui_sensor_available` 报 0、`ui_sensor` 返回 0。
 *   **别把"读不到"当成"读到了 0"** —— 那会让程序以为"手机放平了"。
 */
int ui_sensor(int kind, int* out) {
    int op;
    /* ⚠ **操作码必须占 R0**，种类才在 R1、缓冲区在 R2 —— 漏了这个 `op`
     *   （`asm("SYSCALL #554, ${kind}, ${out}")`）时，`kind` 会被当成操作码、
     *   输出**指针**被当成种类 ⇒ 宿主看到的是一个巨大的种类、直接返回 -1。
     *   症状是"传感器永远读不到"，而包装函数看着完全正常。实测踩过（v0.96.492）。
     *   ⚠ 与 `ui_clip_push` 一样，操作码要写成 **`${变量}`** ——
     *   字面量在 asm 串里会被整个丢掉、参数整体前移一格（见本文件开头那条说明）。 */
    op = 0;
    return asm("SYSCALL #554, ${op}, ${kind}, ${out}");
}

int ui_sensor_available(int kind) {
    int op;
    int z;
    op = 1;
    z = 0;
    return asm("SYSCALL #554, ${op}, ${kind}, ${z}");
}

int ui_sensor_rate(int kind, int ms) {
    int op;
    op = 2;
    return asm("SYSCALL #554, ${op}, ${kind}, ${ms}");
}

int ui_sensor_calibrate(int kind) {
    int op;
    int z;
    op = 3;
    z = 0;
    return asm("SYSCALL #554, ${op}, ${kind}, ${z}");
}

/* 面向**不支持指针的语言**（Python/BASIC/…）的取传感器接口 —— 与 `ui_touch_query`
 * 那一套同构：
 *
 *     ok = ui_sensor_query(0)      # 0 = 加速度
 *     x = ui_sensor_x();  y = ui_sensor_y();  z = ui_sensor_z()
 *
 * ⚠ 一次只保留**最近一次查询**的结果（单缓冲），与触摸那几个访问器同一口径。
 */
static int _ui_sensor_x;
static int _ui_sensor_y;
static int _ui_sensor_z;

int ui_sensor_query(int kind) {
    int tmp[3];
    int ok;
    tmp[0] = 0; tmp[1] = 0; tmp[2] = 0;
    ok = ui_sensor(kind, tmp);
    _ui_sensor_x = tmp[0];
    _ui_sensor_y = tmp[1];
    _ui_sensor_z = tmp[2];
    return ok;
}

int ui_sensor_x(void) { return _ui_sensor_x; }

/* ── 电量与省电（`POWER` #540，v0.96.494）─────────────────────────────────
 *
 * `R0`=操作码（0 电量 / 1 省电模式），参数从 `R1` 起。
 *
 * **为什么值得有**：玩到一半没电是手机游戏最常见的"事故"，而程序自己就能防 ——
 * 电量低了少画点东西、关掉音效、提醒玩家存档。而这一切**不需要任何权限**。
 *
 *     int b[2];
 *     if (ui_battery(b) && b[0] < 15 && b[1] == 0) {
 *         low_power_mode();      // 没在充电、又是低电量 ⇒ 该省了
 *     }
 *
 * ⚠ 电量变得很慢，**不必每帧查** —— 在"每拍跑一次"的逻辑里顺手看一眼就够
 *   （每帧查是在白白多走一趟 syscall）。
 * ⚠ **没有电池的设备返回 0**（桌面、一直插电的机器）。别拿 100 冒充满电 ——
 *   那会让程序以为"电很足"，而真相是"这个问题在这里没有意义"。
 * ⚠ `ui_battery` 与 `ui_battery_level/charging` 是**两条路**：
 *   前者每次都问宿主，后者读**上一次问到的**（给拿不到指针的语言用，与触摸那套同构）。
 */
int ui_power(int op, int* out) {
    /* ⚠ 操作码必须占 R0，且要写成 `${变量}` —— 字面量在 asm 串里会被丢掉。 */
    return asm("SYSCALL #540, ${op}, ${out}");
}

int ui_battery(int* out) {
    int op;
    op = 0;
    return asm("SYSCALL #540, ${op}, ${out}");
}

int ui_power_saver(void) {
    int op;
    int z;
    op = 1;
    z = 0;
    return asm("SYSCALL #540, ${op}, ${z}");
}

/* 上一次 `ui_battery` 查到的值（单缓冲，与 `ui_touch_query` 那一套同口径）。 */
static int _ui_bat_level;
static int _ui_bat_charging;

int ui_battery_query(void) {
    int tmp[2];
    int ok;
    tmp[0] = 0; tmp[1] = 0;
    ok = ui_battery(tmp);
    _ui_bat_level = tmp[0];
    _ui_bat_charging = tmp[1];
    return ok;
}

int ui_battery_level(void) { return _ui_bat_level; }
int ui_battery_charging(void) { return _ui_bat_charging; }
int ui_sensor_y(void) { return _ui_sensor_y; }
int ui_sensor_z(void) { return _ui_sensor_z; }

int ui_orient_lock(int mode) {
    return asm("SYSCALL #558, ${mode}");
}

int ui_immersive(int on) {
    return asm("SYSCALL #559, ${on}");
}

/* ── 音频（541，一个号 + 操作码；v0.96.484 合并，原先 541/542/543/547 四个号）──
 *
 * ⚠ 原先这组**只有 `ui_audio_playing` 一个出口**，另外三个（播放/停止/音量）宿主里
 *   实现都在、却没有 C 包装 ⇒ 22 门语言一个都调不到，等于死号。这一版一并补齐。 */
#define VML_AUDIO_OP_PLAY       0
#define VML_AUDIO_OP_STOP       1
#define VML_AUDIO_OP_VOLUME     2
#define VML_AUDIO_OP_IS_PLAYING 3
/* ⚠ 下面三个是 v0.96.485 **追加在末尾**的（op 数值编进程序机器码里，不能插队、不能改值）。
 *   上面四个是**播放文件**（BGM），下面三个是**现场合成**（音符）。 */
#define VML_AUDIO_OP_NOTE_ON    4
#define VML_AUDIO_OP_NOTE_OFF   5
#define VML_AUDIO_OP_CONTROL    6

/* `ui_tone_ctl` 的控制码（与宿主的 `VmlUi.AudioCtl` 同值；**只能末尾追加**） */
#define VML_TONE_CTL_ALL_OFF    0
#define VML_TONE_CTL_WAVE       1
#define VML_TONE_CTL_MAX_VOICES 2
#define VML_TONE_CTL_VOICES     3
#define VML_TONE_CTL_PANIC      4

/* 波形（与 `VmlUi.ClampTone` 的 0..3 口径一致） */
#define VML_WAVE_SINE     0
#define VML_WAVE_SQUARE   1
#define VML_WAVE_SAW      2
#define VML_WAVE_TRIANGLE 3

/* 同时能响的声部上限（宿主侧 `VmlToneSynth.MaxVoices`） */
#define VML_TONE_MAX_VOICES 32

/* 播放一个音频文件（相对路径按沙箱根解）。`loop` 非 0 = 循环（BGM 用）。
 * 返回 0 成功 / -1 失败（文件不存在 / 路径非法 / 平台不支持）。 */
int ui_audio_play(char* path, int loop) {
    int op = VML_AUDIO_OP_PLAY;
    return asm("SYSCALL #541, ${op}, ${path}, ${loop}");
}

/* 停掉正在播的音频。 */
void ui_audio_stop(void) {
    int op = VML_AUDIO_OP_STOP;
    asm("SYSCALL #541, ${op}");
}

/* 设置整体音量（0–100，超出会被钳）。对**之后**播放的音生效。 */
void ui_audio_volume(int volume) {
    int op = VML_AUDIO_OP_VOLUME;
    asm("SYSCALL #541, ${op}, ${volume}");
}

/* 还在播吗 → 1/0（"等这首放完再进下一段"用它）。 */
int ui_audio_playing(void) {
    int op = VML_AUDIO_OP_IS_PLAYING;
    return asm("SYSCALL #541, ${op}");
}

/* ── 复音发声（v0.96.485）──────────────────────────────────────────────
 *
 * 与上面 `ui_audio_*` 的分工：那四个是**播放文件**（BGM），这几个是**现场合成**（音符）。
 * 音符号是**真 MIDI 语义**：A4 = 69 = 440Hz、中央 C(do) = 60。
 *
 * ⚠ **复音 = 多个声部同时响**（最多 `VML_TONE_MAX_VOICES` 个）。
 *   `ui_beep` 那条"一次只发一个音"的老限制在这里**不存在** ——
 *   按和弦就是连续 `ui_tone_on` 几个不同通道、中间不 `ui_tone_off`：
 *
 *       ui_tone_on(0, 60, 100);   // do
 *       ui_tone_on(1, 64, 100);   // mi
 *       ui_tone_on(2, 67, 100);   // sol   ← 三个音**同时在响**
 *       ...
 *       ui_tone_off(0, 60); ui_tone_off(1, 64); ui_tone_off(2, 67);
 *
 *   `ui_beep` 自己的老语义（连发只听见最后一个）**原样保留**，两者互不干扰：
 *   蜂鸣占一条自己的专用声道，不吃掉和弦里的任何声部。
 *
 * ⚠ 参数**一律钳、不拒**：越界的音符号会被钳到 0–127 继续响，而不是默默不发声。
 */

/* 起一个音：`ch` 通道 0–15、`note` 音符号 0–127、`vel` 力度 0–127（**0 等同关音**）。
 * 返回 0 成功 / -1 参数非法。 */
int ui_tone_on(int ch, int note, int vel) {
    int op = VML_AUDIO_OP_NOTE_ON;
    return asm("SYSCALL #541, ${op}, ${ch}, ${note}, ${vel}");
}

/* 关一个音：`note` 传 **-1** 表示"该通道上所有音"。
 * 返回 0 成功 / -1 那个音本来就没在响。 */
int ui_tone_off(int ch, int note) {
    int op = VML_AUDIO_OP_NOTE_OFF;
    return asm("SYSCALL #541, ${op}, ${ch}, ${note}");
}

/* 控制码的统一出口。
 * ⚠ 参数全部走形参：`asm` 串里的**字面量会被丢掉**（本文件上面几处都记过这条）。 */
static int _ui_tone_ctl(int ctl, int a, int b) {
    int op = VML_AUDIO_OP_CONTROL;
    return asm("SYSCALL #541, ${op}, ${ctl}, ${a}, ${b}");
}

/* 所有音走**淡出**（不是硬切 —— 硬切会"咔"）。 */
int ui_tone_all_off(void) { return _ui_tone_ctl(VML_TONE_CTL_ALL_OFF, 0, 0); }

/* 设通道的默认波形（`VML_WAVE_*`）。 */
int ui_tone_wave(int ch, int wave) { return _ui_tone_ctl(VML_TONE_CTL_WAVE, ch, wave); }

/* 同时允许的声部上限（1–32）。 */
int ui_tone_max_voices(int n) { return _ui_tone_ctl(VML_TONE_CTL_MAX_VOICES, n, 0); }

/* 此刻在响的声部数（0–32）—— 查"和弦有没有真的叠起来"用它。 */
int ui_tone_voices(void) { return _ui_tone_ctl(VML_TONE_CTL_VOICES, 0, 0); }

/* 立刻全停（**不进淡出**）。用于"用户强制停止 / 页面被销毁"这类场合。 */
int ui_tone_panic(void) { return _ui_tone_ctl(VML_TONE_CTL_PANIC, 0, 0); }

/* ── 音效音序器 ────────────────────────────────────────────────────────
 *
 * 为什么这一层在**库里**，而不是每个游戏自己写一遍：
 *
 *   ① `ui_tone_on` **没有时长参数** —— 响多久全看自己什么时候 `ui_tone_off`。
 *      事件点上 on、忘了 off，声部就只涨不落（上限 `VML_TONE_MAX_VOICES` = 32，
 *      满了以后新音**全哑，而且一声不响地哑**）。
 *   ② 好听的音效是**几个音先后**（"叮—咚"、上行三音），而事件点只有一拍 ⇒
 *      要"过几拍再响下一个"。
 *   ③ 同一个**通道**上后一个音会掐掉前一个（这正是 `ui_beep` 的老语义）⇒
 *      "同时响"必须落在不同通道上，得有一处统一分配。
 *
 * 三条合起来 = 一张小表 + 每拍推进一次。**机制在这儿，音色留在各游戏里** ——
 * 哪个事件配什么音是设计，不是机制（同一个"爆炸"，机甲游戏和种田游戏要的不一样）。
 *
 * 用法（`tick` 每拍调一次）：
 *
 *     ui_sfx_add(3, 72, 0, 4, 95, VML_WAVE_SQUARE);   // do，立刻响 4 拍
 *     ui_sfx_add(4, 76, 1, 4, 85, VML_WAVE_SQUARE);   // mi，晚一拍起
 *     ui_sfx_add(5, 79, 2, 6, 85, VML_WAVE_SQUARE);   // sol
 *     ...
 *     ui_sfx_tick();                                   // 主循环里每帧一次（它自己按
 *                                                      //   真实流逝时间补拍，你不用管）
 *
 * ⚠ **`ui_sfx_tick` 放在主循环里**，别挂在会被提前杀掉的定时器上 —— 一局结束那一刻
 *   物理定时器往往就被 kill 了，而胜负音正要开始放，结果**只响得出第一个音**
 *   （症状很像"音效没做"，实际是驱动源选错了）。
 *
 * ⚠ **通道分配由调用方定，但要按"谁与谁可能同拍"分区** —— 两个可能同时发生的
 *   音效共用通道时，后者会把前者的槽顶掉：表现是**静默少一个音**，日志上只是
 *   少两行。建议：0–2 爆炸 / 3–5 得分 / 6–7 发射 / 8–9 空中 / 10–12 警报 / 13–15 胜负。
 *
 * ⚠ 低音别写太低：手机外放在 200Hz 以下衰减很快，C2(65Hz) 出来是"噗"一声闷响，
 *   玩家听着像**没响**而不是"低沉"。轰鸣的基音落在 C3(130Hz) 上下比较稳。
 */
#define UI_SFX_SLOTS 16

static int _ui_sfx_ch[UI_SFX_SLOTS];
static int _ui_sfx_note[UI_SFX_SLOTS];
static int _ui_sfx_del[UI_SFX_SLOTS];    /* 还差几拍开响（0 = 落到这一拍就响） */
static int _ui_sfx_dur[UI_SFX_SLOTS];    /* 响几拍 */
static int _ui_sfx_vel[UI_SFX_SLOTS];
static int _ui_sfx_wave[UI_SFX_SLOTS];
static int _ui_sfx_on[UI_SFX_SLOTS];     /* 1 = 已经 note_on、还等着 note_off */
static int _ui_sfx_rdy = 0;              /* 静态区是 0，而"空槽"用 -1 表示 ⇒ 要懒初始化一次 */

/* 清表（**不发声**）。⚠ 只清表不关音 = 已经在响的那些**从此没人管**，
 * 所以要"静音"请用 `ui_sfx_panic()`。 */
void ui_sfx_reset(void) {
    int i;
    for (i = 0; i < UI_SFX_SLOTS; i = i + 1) {
        _ui_sfx_ch[i] = -1;
        _ui_sfx_note[i] = -1;
        _ui_sfx_del[i] = 0;
        _ui_sfx_dur[i] = 0;
        _ui_sfx_vel[i] = 0;
        _ui_sfx_wave[i] = -1;
        _ui_sfx_on[i] = 0;
    }
    _ui_sfx_rdy = 1;
}

static void _ui_sfx_ensure(void) {
    if (_ui_sfx_rdy == 0) ui_sfx_reset();
}

/* 立刻静音：先把在响的全关掉、再清表。
 * ⚠ **顺序不能反** —— 先清表就丢掉了"哪些通道在响"，那些声部会一直响到程序结束。 */
void ui_sfx_panic(void) {
    int i;
    _ui_sfx_ensure();
    for (i = 0; i < UI_SFX_SLOTS; i = i + 1) {
        if (_ui_sfx_on[i] != 0) ui_tone_off(_ui_sfx_ch[i], _ui_sfx_note[i]);
    }
    ui_tone_panic();          /* 兜底：表外的（老式 `ui_beep` 那条声道）也一并停 */
    ui_sfx_reset();
}

/* 往表里塞一个音：`delay` 拍之后开始响、响 `dur` 拍。
 *
 * ⚠ 会**先接管同通道的旧槽**，接管之前**先把那个音关掉** —— 不然旧槽连同
 *   "它还在响"这件事一起被丢掉，那个声部就再也没人去关它了。 */
void ui_sfx_add(int ch, int note, int delay, int dur, int vel, int wave) {
    int i;
    int slot;
    _ui_sfx_ensure();
    slot = -1;
    for (i = 0; i < UI_SFX_SLOTS; i = i + 1) {
        if (_ui_sfx_ch[i] == ch) {
            if (_ui_sfx_on[i] != 0) ui_tone_off(_ui_sfx_ch[i], _ui_sfx_note[i]);
            slot = i;
        }
    }
    if (slot < 0) {
        for (i = 0; i < UI_SFX_SLOTS; i = i + 1) {
            if (_ui_sfx_ch[i] < 0) slot = i;
        }
    }
    if (slot < 0) return;     /* 表满：宁可少一个音，也不要越界 */

    _ui_sfx_ch[slot] = ch;
    _ui_sfx_note[slot] = note;
    _ui_sfx_del[slot] = delay;
    _ui_sfx_dur[slot] = dur;
    _ui_sfx_vel[slot] = vel;
    _ui_sfx_wave[slot] = wave;
    _ui_sfx_on[slot] = 0;
}

/* 推进**一拍**：`delay` 到了就 note_on，`dur` 响完就 note_off 并腾出槽位。
 *
 * ⚠ 一般**不用**直接调它 —— 用 `ui_sfx_tick()`（它按真实流逝时间替你补拍）。
 *   这一支留给"自己的节拍就是基准、要手动控速"的场合。 */
void ui_sfx_step(void) {
    int i;
    _ui_sfx_ensure();
    for (i = 0; i < UI_SFX_SLOTS; i = i + 1) {
        if (_ui_sfx_ch[i] >= 0) {
            if (_ui_sfx_on[i] == 0) {
                if (_ui_sfx_del[i] > 0) {
                    _ui_sfx_del[i] = _ui_sfx_del[i] - 1;
                } else {
                    ui_tone_wave(_ui_sfx_ch[i], _ui_sfx_wave[i]);
                    ui_tone_on(_ui_sfx_ch[i], _ui_sfx_note[i], _ui_sfx_vel[i]);
                    _ui_sfx_on[i] = 1;
                }
            } else {
                _ui_sfx_dur[i] = _ui_sfx_dur[i] - 1;
                if (_ui_sfx_dur[i] <= 0) {
                    ui_tone_off(_ui_sfx_ch[i], _ui_sfx_note[i]);
                    _ui_sfx_ch[i] = -1;
                    _ui_sfx_note[i] = -1;
                    _ui_sfx_wave[i] = -1;
                    _ui_sfx_on[i] = 0;
                }
            }
        }
    }
}

/* 每帧调一次：**按真实流逝时间自动补拍**（内部读 `ui_tick()`）。
 *
 * 把"该走几拍"这件事收进库，是因为每个调用方都需要它、而且都需要**一模一样**的它 ——
 * 否则每份游戏里都会出现同一段 12 行的补拍循环（本仓最忌讳的那种重复）。
 *
 * ⚠ **放在主循环里**，别挂在会被提前杀掉的定时器上：一局结束那一刻物理定时器往往
 *   就被 kill 了，而胜负音正要开始放，结果**只响得出第一个音**（症状很像"音效没做"）。
 * ⚠ 上限 4 拍：卡顿一下（GC / 切后台）不该让音效"补跑"一串回来。
 */
static int _ui_sfx_last = 0;

void ui_sfx_tick(void) {
    int now;
    int n;
    _ui_sfx_ensure();
    now = ui_tick();
    if (_ui_sfx_last == 0) { _ui_sfx_last = now; return; }
    n = (now - _ui_sfx_last) / 33;      /* 一拍 = 33ms */
    if (n > 4) n = 4;
    if (n > 0) {
        _ui_sfx_last = now;
        while (n > 0) { ui_sfx_step(); n = n - 1; }
    }
}

/* 表里还有几个槽占着（待响 + 在响）。**没声音可放时返回 0** ——
 * 拿它做自检的判据（"放完一轮之后必须回到 0"），比看日志靠谱。 */
int ui_sfx_active(void) {
    int i;
    int n;
    _ui_sfx_ensure();
    n = 0;
    for (i = 0; i < UI_SFX_SLOTS; i = i + 1) {
        if (_ui_sfx_ch[i] >= 0) n = n + 1;
    }
    return n;
}

/* 帧边界标记（本帧画完了）。 */
void ui_present(void) {
    asm("SYSCALL #531");
}

/* ── 像素读回（583–585）────────────────────────────────────────────────
 *
 * 老 graphics.h 程序做**填充**与**精灵**绕不开读像素，而场景是保留模式的
 * ⇒ 宿主侧要先光栅化一次。三个号的分工见 `waycoder_ui.h` 的同名声明。
 *
 * ⚠ **多参数必须写在同一个 `asm()` 里**：每个 `${}` 展开都会先载入 R0，
 *   拆成多个 `asm()` 会互相覆盖寄存器（本仓记过这个坑）。
 */

/* 从 (x,y) 灌色，碰到 border 色停。返回落笔的矩形条数（0 = 没填）。 */
int ui_flood_fill(int x, int y, int color, int border) {
    return asm("SYSCALL #583, ${x}, ${y}, ${color}, ${border}");
}

/* 存一块画面 → 句柄（≥1），失败 0。 */
int ui_get_image(int x, int y, int w, int h) {
    return asm("SYSCALL #584, ${x}, ${y}, ${w}, ${h}");
}

/* 把句柄那块贴到 (x,y)。mode：0=COPY 直接贴 / 1=XOR 异或。返回 1 成功。 */
int ui_put_image(int x, int y, int handle, int mode) {
    return asm("SYSCALL #585, ${x}, ${y}, ${handle}, ${mode}");
}

/* ── 矢量图块（589，一个号 + 操作码）──────────────────────────────────
 *
 * 与上面那对 ui_get_image / ui_put_image 是**两条并存的路**：
 *   像素路：存光栅像素（w×h×4 字节）—— 老程序的 GET/PUT 用它；放大要重采样、转不了。
 *   矢量路：存**绘图指令** —— 放大不糊、旋转免费、内存与图块尺寸无关。
 *
 * ⚠ **底层只有一个号（589）**：`R0` 是操作码（见 waycoder_ui.h 的 VML_BLOCK_*），
 *   参数从 `R1` 起。原先这里是 589–593 五个号，合并后**函数名与签名一个都没变**，
 *   程序照旧写 ui_create_block / ui_draw_block —— 它们各自在这里发同一条 SYSCALL。
 *
 * 用法：
 *     h = ui_create_block(32, 32, 0);
 *     ui_rect(0, 0, 32, 32, 0xFF0000, 1, 0, 0);
 *     ...
 *     ui_end_block();
 *     ui_draw_block(h, 200, 300, 1000, 1000, 45);   // 中心在 (200,300)、原尺寸、转 45°
 *
 * ⚠ 块表**不随 ui_clear 清** —— 造一次、之后一直贴。每帧 create 一遍会在 128 帧后拿不到句柄。
 * ⚠ 块里要用渐变/刷子，就在 ui_create_block **之后**建（理由见 waycoder_ui.h）。
 * ⚠ `asm` 串里的 `${}` 展开**总是先载入 R0** ⇒ 操作码写成 `${op}` 那个变量，
 *   **不要**直接写字面量 `0`/`1`（字面量会被丢弃，操作码位置就空了）。
 *
 * ⚠ 操作码定义在**本文件**（本文件不 include 头文件，理由见上面 VML_BRUSH_* 那段注释）；
 *   `Lib/c/waycoder_ui.h` 里有同一份给用户程序用 —— **改一边必须改另一边**。
 */

#define VML_BLOCK_CREATE   0
#define VML_BLOCK_END      1
#define VML_BLOCK_DRAW     2
#define VML_BLOCK_DRAW_AT  3
#define VML_BLOCK_FREE     4

/* 开始录一个图块。w×h 是尺寸声明（中心版贴图要用它算中心）；color 是**保留位** ——
 * 图块永远**透明叠加**，传什么都没有区别。
 * 返回句柄（≥1）；0 = 失败（已经在录了 / 块表满 128）。 */
int ui_create_block(int w, int h, int color) {
    int op = VML_BLOCK_CREATE;
    return asm("SYSCALL #589, ${op}, ${w}, ${h}, ${color}");
}

/* 结束录制。返回句柄（与 ui_create_block 给的那个一致）；0 = 没在录制。 */
int ui_end_block(void) {
    int op = VML_BLOCK_END;
    return asm("SYSCALL #589, ${op}");
}

/* 贴图块：**(x,y) 是图块中心，绕中心旋转**。
 * sx/sy 用**千分比**（1000 = 原尺寸、2000 = 两倍），rot 用**度**。返回 1 成功 / 0 失败。 */
int ui_draw_block(int block, int x, int y, int sx, int sy, int rot) {
    int op = VML_BLOCK_DRAW;
    return asm("SYSCALL #589, ${op}, ${block}, ${x}, ${y}, ${sx}, ${sy}, ${rot}");
}

/* 同上，但 **(x,y) 是图块左上角、绕左上角旋转**。 */
int ui_draw_block_at(int block, int x, int y, int sx, int sy, int rot) {
    int op = VML_BLOCK_DRAW_AT;
    return asm("SYSCALL #589, ${op}, ${block}, ${x}, ${y}, ${sx}, ${sy}, ${rot}");
}

/* **释放**一个图块（句柄回收再用）。返回 1 成功 / 0 失败（句柄不存在或已释放）。
 *
 * 块的**内容与尺寸都不可改**，"更新一个块"的唯一办法是重录 ——
 * 没有本函数时那就是在漏句柄（块表 128 格，满了之后 ui_create_block 一律返回 0，
 * 而画面只是"悄悄退回逐帧画"，很难发现）。 */
int ui_free_block(int block) {
    int op = VML_BLOCK_FREE;
    return asm("SYSCALL #589, ${op}, ${block}");
}

/* **释放**一张 ui_get_image 存下的图像（句柄回收）。返回 1 成功 / 0 失败。
 *
 * 图像表是**宿主级**的、不随场景释放，所以程序自己主动释放才有意义
 * （退出时宿主会统一清掉）。 */
int ui_free_image(int handle) {
    return asm("SYSCALL #594, ${handle}");
}

/* ── 老 BASIC 的精灵位图（`DATA` 手打包 + `PUT`）────────────────── */

/* 读一个像素的颜色 → **0xRRGGBB**（越界返回 -1）。异或擦除要用。
 * ⚠ 每次调用宿主都要**光栅化一次**（场景是保留模式的），别放进密集大循环。 */
int ui_get_pixel(int x, int y) {
    return asm("SYSCALL #587, ${x}, ${y}");
}

/* ── 主动截屏（588）────────────────────────────────────────────────────
 *
 * 把**画布**（程序自己画的东西）存成 PNG 文件。与上面三个的分工：
 * 那几个是给程序在运行中读像素用的（句柄 / 单点），这个是把整幅画面存下来给用户看。
 *
 * ⚠ 截的是**画面本身**，不含屏幕手柄与标题栏 —— 当战绩图/分享图用，干净的画面更好。
 *   实现走的是共享光栅器（四端同一份代码），不依赖任何平台截屏 API。
 */

/* 把当前画布存成 PNG，写进 path（相对路径）。
 * 返回写入的字节数；-1 = 路径非法 / 还没有画布 / 写不进去（不区分）。
 * ⚠ path 里不许有 ".." 与盘符（宿主要求相对沙箱路径），否则直接 -1。
 * **空串 = 自动命名**：`shot/<窗口标题>_<日期>_<时间>.png`
 *（如 `shot/五子棋_20260924_102801.png`），省得程序自己拼名字。 */
int ui_screenshot(char* path) {
    return asm("SYSCALL #588, ${path}");
}

/* 把一块**手打包在 `DATA` 里的 QBasic 位图**贴到 (x,y)。
 *
 * ## 为什么要它
 *
 * 老 BASIC 游戏的精灵**不是 GET 抓下来的**，而是把位图按 QBasic 的 GET/PUT
 * 数组格式**手打进 `DATA`**、`READ` 进一个长整型数组，再 `PUT (x,y), 数组, PSET/XOR`。
 * （GORILLA.BAS 的 `LBan&` 就是 —— `LBan&(0) = 458758`。）
 * 宿主那套 `ui_put_image` 只认 `ui_get_image` 给的**句柄**，所以这类精灵
 * **一个都画不出来**，而且程序侧一个错都不报。
 *
 * ## 块格式（**实测定的，不是猜的**）
 *
 *   arr[0]（4 字节头）：**低字 = 宽、高字 = 高**（就是宽高本身，**不是减一**）
 *   arr[1] 起          ：像素，**逐行**；每行里**按平面依次**放
 *                        `ceil(宽/8)` 个字节；字节的**最高位是最左像素**
 *   颜色               ：`color = p0 | p1<<1 | p2<<2 | p3<<3`（EGA 模式 9 四个平面）
 *
 * 判据：把 GORILLA.BAS 那四个香蕉解出来渲染成点阵 —— 左/右互为**水平镜像**、
 * 上/下互为**垂直镜像**，而且四条都能看出香蕉的弯月形状。四张图都对上了才算数。
 *
 * ## 两个刻意的取舍（都说清楚，免得下次有人以为漏了）
 *
 * ① **颜色 0 的像素跳过**（不画）。QBasic 的 XOR 本来就是这个语义（0 异或 d = d）；
 *    PSET 严格说会把 0 写上去（= 黑），但那样精灵罩住的背景会被一起涂黑 ——
 *    精灵贴在天际线/太阳上时就露馅。跳过后"画一次再擦一次"仍精确还原。
 * ② **XOR 按调色板索引做**（不是按 RGB）。宿主只回 0xRRGGBB，所以这里拿它到
 *    `pal` 里反查索引（16 项）。这一步非做不可 —— 异或的是**索引**正是
 *    "PSET 画、XOR 擦能还原"的全部依据：精灵用索引 14，擦时 14^14 = 0 = 背景色；
 *    按 RGB 异或会得到 #FFFFAA 这种新颜色，画面上留下一串擦不掉的痕迹。
 *    反查不到（宿主自己画的、不在调色板里的颜色）就退回 RGB 异或，不假装。
 */
void ui_put_qb_bitmap(int x, int y, int* arr, int* pal, int planes, int action) {
    int hdr, w, h, bprow, row, col, p, color, src, dst, off, b;
    char* data;

    hdr = arr[0];
    w = hdr & 65535;
    h = (hdr >> 16) & 65535;
    if (w <= 0 || h <= 0) return;
    if (planes <= 0) return;

    data = (char*)arr + 4;          /* 跳过那 4 字节头 */
    bprow = (w + 7) / 8;

    for (row = 0; row < h; row++) {
        for (col = 0; col < w; col++) {
            color = 0;
            for (p = 0; p < planes; p++) {
                off = (row * planes + p) * bprow + (col >> 3);
                b = data[off] & 255;
                if (b & (128 >> (col & 7))) color = color | (1 << p);
            }
            if (color != 0) {
                src = pal[color & 15];
                if (action == 1) {
                    dst = ui_get_pixel(x + col, y + row);
                    if (dst >= 0) {
                        /* 按**调色板索引**异或，不是按 RGB —— 这是 QBasic 的语义，
                         * 也是"PSET 画、XOR 擦能还原"的全部依据：
                         * 精灵用的是索引 14，擦的时候 14^14 = 0 = 背景色 ⇒ 精确还原。
                         * RGB 异或做不到这件事（#FFFF00 ^ #0000AA = #FFFFAA，是个新颜色）。
                         * 目的色反查索引：拿宿主回的 RGB 在调色板里找（16 项，够快）。
                         * 找不到（宿主自己画的颜色，不在调色板里）就退回 RGB 异或 —— 不假装。 */
                        int idx = -1, k;
                        for (k = 0; k < 16; k++)
                            if ((pal[k] & 0xFFFFFF) == (dst & 0xFFFFFF)) { idx = k; break; }
                        if (idx >= 0) src = pal[(idx ^ color) & 15];
                        else src = 0xFF000000 | ((src ^ dst) & 0xFFFFFF);
                    }
                }
                ui_pixel(x + col, y + row, src);
            }
        }
    }
}

/* ── 文字 ───────────────────────────────────────────────── */

/* 一次性画一行字。anchor: 0=左 1=中 2=右；style: 1=粗 2=斜。 */
void ui_text(int x, int y, char* s, int color, int size, int anchor) {
    /* ⚠ **必须显式把 R6（样式位）压成 0** —— 这是真机上抓到的 bug：
     *   `#528` 把 R6 当样式位读（bit0 粗 / bit1 斜），而**这个 6 参数的版本不碰 R6**
     *   ⇒ 程序上一条指令留在 R6 里的值会被当成样式。
     *   最典型的触发：先 `ui_rect(..., lw, radius)`（8 个参数，**线宽落在 R6**），
     *   再 `ui_text(...)` ⇒ 线宽 6 = `110b` ⇒ **斜体位开着**，之后所有文字都变斜。
     *   实测：设备日志 `#528 regs=[...,6,0]`，截图里字全斜、屏幕上却"粗而不斜"
     *   （两条渲染路径对 italic 的处理还不同，于是两端还不一致）。
     *
     *   `${}` 只认**局部变量**，所以先落到一个局部量再当第 7 个占位符传下去 ——
     *   写死在 asm 文本里的字面量**不会**被装配进寄存器（本仓记过这个坑）。 */
    int no_style;
    no_style = 0;
    asm("SYSCALL #528, ${x}, ${y}, ${s}, ${color}, ${size}, ${anchor}, ${no_style}");
}

void ui_text_styled(int x, int y, char* s, int color, int size, int anchor, int style) {
    asm("SYSCALL #528, ${x}, ${y}, ${s}, ${color}, ${size}, ${anchor}, ${style}");
}

/* 带**竖对齐**的文字。valign: 0=顶（= 老行为）1=中 2=底；style: 1=粗 2=斜。
 * 新号 #581 —— 给老号 #528 加参数会让老程序读到自己上一句留下的垃圾值。 */
void ui_text_v(int x, int y, char* s, int color, int size, int anchor, int valign, int style) {
    asm("SYSCALL #581, ${x}, ${y}, ${s}, ${color}, ${size}, ${anchor}, ${valign}, ${style}");
}

/* 设置当前文字属性：字号 / 样式位 (1=粗 2=斜) / 颜色 / 锚点。
 * ⚠ 竖对齐**不在这里**（见下面的 ui_set_valign）—— 给这个号加第 5 个参数会让只传四个的
 *   老程序读到自己上一句留下的垃圾值。 */
void ui_set_font(int size, int style, int color, int anchor) {
    asm("SYSCALL #532, ${size}, ${style}, ${color}, ${anchor}");
}

/* 设"当前文字"的竖对齐（状态式，配 ui_text_cur 用）：
 * 0=顶（默认，盒顶落在 y）/ 1=中 / 2=底 / 3=**基线**（y 就是基线）。
 * 新号 #586 —— 理由同 ui_set_font 上面那条。 */
void ui_set_valign(int valign) {
    asm("SYSCALL #586, ${valign}");
}

/* 用**当前文字属性**画一行字（属性由 ui_set_font 设定）。 */
void ui_text_cur(int x, int y, char* s) {
    asm("SYSCALL #533, ${x}, ${y}, ${s}");
}

/* ── 输入（统一消息队列）────────────────────────────────────
 *
 * 消息缓冲固定 **16 字节 = 4 个 int**：msg[0]=类型 msg[1]=A msg[2]=B msg[3]=时间戳
 * 触摸类消息：A=x，B=y（单位与绘图一致）。
 *
 * ⚠ **底层只有一个号（560）**：`R0` 是操作码（下面这组宏）、参数从 `R1` 起。
 *   原先这里是 560/561/562/568/571/572/596 **七个号**（v0.96.483 合并）——
 *   宿主侧 `Poll`/`Wait` **本来就是同一份实现**、只差一个保留位。
 *   **函数名与签名一个都没变**，程序照旧写下面的函数即可。
 * ⚠ 操作码定义在**本文件**（本文件不 include 头文件，理由见 VML_BRUSH_* 那段注释）；
 *   `Lib/c/waycoder_ui.h` 里有同一份给用户程序用 —— **改一边必须改另一边**。
 * ⚠ `asm` 串里的 `${}` 展开**总是先载入 R0** ⇒ 操作码写成 `${op}` 那个变量，
 *   **不要**直接写字面量（字面量会被丢弃，操作码位置就空了）。 */

#define VML_MSG_OP_POLL     0
#define VML_MSG_OP_WAIT     1
#define VML_MSG_OP_COUNT    2
#define VML_MSG_OP_CLEAR    3
#define VML_MSG_OP_DROP     4
#define VML_MSG_OP_POLL_EX  5
#define VML_MSG_OP_WAIT_EX  6

/* 非阻塞取一条。返回消息类型，无消息 0。 */
int ui_poll(int* msg) {
    int op = VML_MSG_OP_POLL;
    return asm("SYSCALL #560, ${op}, ${msg}");
}

/* 阻塞取一条，timeout_ms=0 表示无限等。返回消息类型，超时 0。 */
int ui_wait(int* msg, int timeout_ms) {
    int op = VML_MSG_OP_WAIT;
    return asm("SYSCALL #560, ${op}, ${msg}, ${timeout_ms}");
}

/* 读一条，带"读完之后留不留"（VML_MSG_KEEP / VML_MSG_CONSUME）。
 * 保留模式只**看**队头那一条，队列里一个都不少 —— 下一次读到的还是它，
 * 直到程序明确地消费掉。想"先看一眼再决定谁来处理"时用；
 * ⚠ **别拿它当循环条件**：保留模式下永远返回同一条 = 死循环。 */
int ui_poll_ex(int* msg, int keep) {
    int op = VML_MSG_OP_POLL_EX;
    return asm("SYSCALL #560, ${op}, ${msg}, ${keep}");
}

int ui_wait_ex(int* msg, int timeout_ms, int keep) {
    int op = VML_MSG_OP_WAIT_EX;
    return asm("SYSCALL #560, ${op}, ${msg}, ${timeout_ms}, ${keep}");
}

/* ── 全能接口：两个字符串进、一个 JSON 字符串出 ────────────────────────
 *
 * 给**不要求性能**的可扩展功能用：加一个能力 = 宿主侧注册一个函数，
 * 不占 syscall 号、不用改这里、也不用重生成 22 种语言的绑定。
 * 绘图/输入这类每帧都发生的东西**别走这里**（一次调用要过两趟 JSON + 一次内存拷贝）。
 *
 * 返回值：写进 out_buf 的字节数（不含结尾 NUL）；-1 = 失败（函数不认识 / 参数非法 /
 * 缓冲区放不下 —— 后面这种情形 out_buf 里会是一段说明原因的信封）。
 * 结果永远是对象：成功 {"ok":true,"result":…}，失败 {"ok":false,"error":"…"}。 */
int ui_call_json(char* fn, char* args_json, char* out_buf, int cap) {
    return asm("SYSCALL #573, ${fn}, ${args_json}, ${out_buf}, ${cap}");
}

/* 给**拿不到缓冲区指针**的前端（Python / BASIC / Lua …）的版本：
 * 结果放进静态缓冲，用下面两个函数按字节读 —— 连 char* 都能不解引用。
 * 容量 4096 够放一般的结果；不够时结果里会是"结果太长"的信封（一眼看得出）。 */
#define UI_JSON_BUF_N 4096
static char _ui_json_buf[UI_JSON_BUF_N];
static int _ui_json_len;

int ui_call_json_s(char* fn, char* args_json) {
    _ui_json_len = ui_call_json(fn, args_json, _ui_json_buf, UI_JSON_BUF_N);
    if (_ui_json_len < 0) {
        _ui_json_len = 0;
    }
    return _ui_json_len;
}

/* 上一次 ui_call_json_s 的结果长度（字节，不含结尾 NUL；失败 0）。 */
int ui_call_json_len(void) {
    return _ui_json_len;
}

/* 把上一次 ui_call_json_s 的结果**整份打到 stdout**（末尾补一个换行）。
 *
 * 存在的理由：跨语言自测要"把结果原样打出来给人看/给脚本比"，而让 22 种语言各自
 * 写一遍"逐字节取 + 单个字符输出"的循环，就是 22 份同一段代码（本仓库头号坑）。
 * 放在这里之后，各语言的自测都只剩两行：`ui_call_json_s(...)` + `ui_call_json_print()`。 */
void ui_call_json_print(void) {
    int i;
    for (i = 0; i < _ui_json_len; i = i + 1) {
        putchar(_ui_json_buf[i]);
    }
    putchar(10);   /* '\n' */
}

/* 结果里第 i 个字节（0..len-1）。越界返回 0 —— 与 ui_gget 一样安全失败。 */
int ui_call_json_at(int i) {
    if (i < 0 || i >= _ui_json_len) {
        return 0;
    }
    return _ui_json_buf[i];
}

int ui_msg_count(void) {
    int op = VML_MSG_OP_COUNT;
    return asm("SYSCALL #560, ${op}");
}

/* 丢掉队列里**所有待处理消息** → 丢弃条数。
 *
 * 一次点击往往产生**多条**消息（按下/抬起/移动各一条），而游戏主循环通常只读它要的那条，
 * 剩下的就留在队列里 —— 于是"重开一局"时 ui_poll 又把**上一局的残留**读出来，
 * 症状是「重新开始后，黑子立刻又落到上次最后点的位置」。
 * 在**重新开始 / 切关 / 暂停恢复**这类状态断点上调它，把历史输入清干净。 */
int ui_msg_clear(void) {
    int op = VML_MSG_OP_CLEAR;
    return asm("SYSCALL #560, ${op}");
}

/* 丢掉队列里**某一类**还没被消费的消息 → 丢掉的条数（-1 = 类别认不出，什么也没丢）。
 *
 * 与 ui_msg_clear 的差别是**只丢一类**：清空是"把历史全部扔掉"，而"我正在拖动、
 * 中间那几百条移动事件已经过期了"这种情形下清空**太狠** —— 会把同一时间排着的
 * 键盘、定时器一起丢掉（程序那边表现为"按键丢了 / 物理卡了一拍"）。
 *
 * ⚠ **移动类消息是"追最新位置"的语义**，旧的位置毫无价值；而主循环是
 *   "一次取一条"（ui_wait_msg），手指拖动一秒能产生几百条 ⇒ 产生的比消费的快，
 *   队列只涨不落。真机实测（gorilla 连续拖滑条 6 轮）：队列 285 → 596 → … → 2280 条
 *   且完全不回落，而同一时间 fps 全程 19~21 —— 用户看到的就是
 *   「背景绘图不卡、但触摸要等一下才反应」。在 TOUCHMOVE 分支里丢一次触摸类，
 *   队列立刻回到个位数。
 *
 * ⚠ **别拿它丢键盘 / 定时器**：那两类是**离散语义**，丢一条就少一次事件。 */
int ui_msg_drop(int kind) {
    int op = VML_MSG_OP_DROP;
    return asm("SYSCALL #560, ${op}, ${kind}");
}

/* ── 面向**不支持指针的语言**（Python/BASIC/…）的取消息接口 ──────────
 *
 * C 里可以直接 `int msg[4]; ui_wait(msg, 0)`，但其它前端拿不到"一块内存的地址"，
 * 也没有办法按 int 下标去读它。所以这里把消息**取出来拆开放进静态变量**，
 * 由三个访问器读 —— 调用方只需要：
 *
 *     t = ui_wait_msg(0)
 *     if t == 6:  x = ui_msg_a();  y = ui_msg_b()
 *
 * ⚠ 一次只保留**最近一条**消息（单缓冲）。要"把队列里积压的都处理完"，
 * 用 `while ui_poll_msg() != 0:` 连取即可 —— 每次取都会刷新这三个值。
 */
static int _ui_msg_type;
static int _ui_msg_a;
static int _ui_msg_b;

/* 取一条消息（timeout_ms=0 无限等），返回类型；内容用下面三个读。 */
int ui_wait_msg(int timeout_ms) {
    int* buf;
    int tmp[4];
    int op;
    op = VML_MSG_OP_WAIT;
    buf = tmp;
    _ui_msg_type = asm("SYSCALL #560, ${op}, ${buf}, ${timeout_ms}");
    _ui_msg_a = tmp[1];
    _ui_msg_b = tmp[2];
    return _ui_msg_type;
}

/* 非阻塞取一条，返回类型（无消息返回 0）。 */
int ui_poll_msg(void) {
    int* buf;
    int tmp[4];
    int op;
    op = VML_MSG_OP_POLL;
    buf = tmp;
    _ui_msg_type = asm("SYSCALL #560, ${op}, ${buf}");
    _ui_msg_a = tmp[1];
    _ui_msg_b = tmp[2];
    return _ui_msg_type;
}

/* 最近一条消息的三个字段。 */
int ui_msg_type(void) { return _ui_msg_type; }
int ui_msg_a(void) { return _ui_msg_a; }
int ui_msg_b(void) { return _ui_msg_b; }

/* ── 通用整数网格（给"没有可靠数组"的语言用）────────────────────────
 *
 * C 里棋盘就是 `int board[200]`，但实测 Python 前端的列表**读可以、写不生效**
 * （`b[i] = v` 之后读回来还是 0），嵌套列表也错 —— 于是棋盘只能放在这边，
 * 由调用方用整数下标读写：
 *
 *     ui_gclear()
 *     ui_gset(3, 1)            # 第 3 格
 *     v = ui_gget(3)
 *
 * 256 个 int 够放 10×20 的棋盘（200）+ 7 种方块的 4×4 位掩码（7）。
 * 越界一律**安全失败**（写丢弃、读返回 0），不抛异常 —— 游戏代码里少一层边界判断。
 */
#define UI_GRID_N 256
static int _ui_grid[UI_GRID_N];

/* 棋盘占 0..199（`BOARD_AT`），7 种方块的掩码紧接着放 200..206 —— 这段布局是**跨语言约定**：
 * `Examples/python/tetris.py` 里写死了 `BOARD_AT = 0` / `MASK_AT = 200`，两边必须对得上。
 *
 * ⚠ **这个宏曾经不存在**：`ui_piece_init` 用了 `MASK_AT` 却没有任何地方定义它，
 *   而当时的前端对未声明标识符是**静默按 0 算**的 ⇒ 掩码实际落在 0..6，
 *   **正好压在前 7 个棋盘格上**（棋盘写 0..6 就把掩码冲了，`ui_piece_cell` 从此返回垃圾）。
 *   一直没暴露，是因为 `GenLib -b` 是**增量**的（`.vml` 比 `.c` 新就跳过）——
 *   直到给本文件加新接口时改了它的 mtime，重编译才把这条打出来：
 *   `error: 未声明的变量 'MASK_AT'`（前端的未定义变量检查是后来加的，
 *   这类"靠 0 蒙对"的代码再也过不去了）。 */
#define MASK_AT 200

void ui_gclear(void) {
    int i;
    for (i = 0; i < UI_GRID_N; i = i + 1) _ui_grid[i] = 0;
}

void ui_gset(int idx, int val) {
    if (idx >= 0 && idx < UI_GRID_N) _ui_grid[idx] = val;
}

int ui_gget(int idx) {
    if (idx >= 0 && idx < UI_GRID_N) return _ui_grid[idx];
    return 0;
}

/* ── 方块几何（给"没有可靠位运算/数组"的语言用）────────────────────
 *
 * 7 种方块各 4 次旋转，每次 4 个格子。**位运算与旋转公式都放这里**：
 * BASIC 只有 AND/OR、没有移位取位，Python 的列表读写也不可靠 ——
 * 各前端只负责"拿坐标 → 画出来 / 判一下"，几何这一层共用一份。
 *
 *   ui_piece_init()                       一次，初始化形状表
 *   ui_piece_cell(pid, rot, which)        第 which 个格子的坐标，打包为 x*16+y；无此格返回 -1
 *
 * `pid` 0..6，`rot` 0..3，`which` 0..3。
 * 坐标以方块**左上角**为原点（4×4 包围盒内），调用方加上落点即可。
 */
static int _ui_piece_rot[7];     /* 当前 pid 的基准掩码在 _ui_grid 的槽位（见 ui_piece_init） */

void ui_piece_init(void) {
    /* 4×4 行优先位掩码，第 r 行第 c 位 = r*4+c */
    ui_gset(MASK_AT + 0, 0x0066);   /* O */
    ui_gset(MASK_AT + 1, 0x0F00);   /* I */
    ui_gset(MASK_AT + 2, 0x006C);   /* S */
    ui_gset(MASK_AT + 3, 0x00C6);   /* Z */
    ui_gset(MASK_AT + 4, 0x00E4);   /* T */
    ui_gset(MASK_AT + 5, 0x0062);   /* L */
    ui_gset(MASK_AT + 6, 0x00E8);   /* J */
    _ui_piece_rot[0] = MASK_AT + 0;
    _ui_piece_rot[1] = MASK_AT + 1;
    _ui_piece_rot[2] = MASK_AT + 2;
    _ui_piece_rot[3] = MASK_AT + 3;
    _ui_piece_rot[4] = MASK_AT + 4;
    _ui_piece_rot[5] = MASK_AT + 5;
    _ui_piece_rot[6] = MASK_AT + 6;
}

/* 4×4 掩码顺时针 90°：位 (r,c) → (c, 3-r) */
static int _ui_rot90(int m) {
    int out;
    int r;
    int c;
    out = 0;
    r = 0;
    while (r < 4) {
        c = 0;
        while (c < 4) {
            if ((m & (1 << (r * 4 + c))) != 0)
                out = out | (1 << (c * 4 + (3 - r)));
            c = c + 1;
        }
        r = r + 1;
    }
    return out;
}

int ui_piece_cell(int pid, int rot, int which) {
    int m;
    int k;
    int r;
    int c;
    int n;

    if (pid < 0 || pid > 6 || which < 0 || which > 3) return -1;

    m = ui_gget(_ui_piece_rot[pid]);
    k = rot % 4;
    while (k > 0) {
        m = _ui_rot90(m);
        k = k - 1;
    }

    /* 数到第 which 个置位 */
    n = 0;
    r = 0;
    while (r < 4) {
        c = 0;
        while (c < 4) {
            if ((m & (1 << (r * 4 + c))) != 0) {
                if (n == which) return c * 16 + r;
                n = n + 1;
            }
            c = c + 1;
        }
        r = r + 1;
    }
    return -1;
}

/* 定时器：每隔 interval_ms 往队列投一条 VML_MSG_TIMER（A=id，B=tag）。
 * ⚠ 底层只有一个号（563）+ 操作码（v0.96.483 合并，原先 563/564 两个号）。 */
#define VML_TIMER_OP_SET   0
#define VML_TIMER_OP_KILL  1

int ui_timer_set(int interval_ms, int tag) {
    int op = VML_TIMER_OP_SET;
    return asm("SYSCALL #563, ${op}, ${interval_ms}, ${tag}");
}

int ui_timer_kill(int id) {
    int op = VML_TIMER_OP_KILL;
    return asm("SYSCALL #563, ${op}, ${id}");
}

/* ── 随机数 / 计时（游戏要用，而只有 C 能直接调 #50/#53）──────
 *
 * 非 C 前端拿不到 syscall，游戏里的"下一个方块""洗牌"就只能自己搓一个劣质
 * 伪随机（或者干脆固定顺序）。放这里一份，各语言共用同一个源。
 */

/* 0..n-1 的随机数（n<=0 返回 0）。 */
int ui_rand(int n) {
    int v;
    if (n <= 0) return 0;
    v = asm("SYSCALL #50");
    /* #50 返回的是 32 位有符号随机数，负数取模在 C 里是负数 ⇒ 先归一到非负 */
    return (v % n + n) % n;
}

/* 自 VM 启动起的毫秒数（单调递增，可作动画相位/超时基准）。 */
int ui_tick(void) {
    return asm("SYSCALL #53");
}

/* ── 图标 / 图片 ────────────────────────────────────────── */

void ui_icon(int x, int y, char* name, int size, int color) {
    asm("SYSCALL #529, ${x}, ${y}, ${name}, ${size}, ${color}");
}

void ui_image(int x, int y, char* path, int w, int h) {
    asm("SYSCALL #530, ${x}, ${y}, ${path}, ${w}, ${h}");
}

/* ── 绘图增强（534–539）：渐变刷子 / 路径与曲线 / 多边形 ──
 *
 * ⚠ 这一组与下面「手感」那 5 个，此前**只在 `Lib/c/waycoder_ui.h` 里声明过、
 *   本文件里没有实现**（2026-09-17 实测）。后果是双重的：
 *     · 桌面 vmlcli 里 `CALL ui_beep` **链不上** ⇒ `KeyNotFoundException` 直接崩
 *       （`Examples/go/snake.go` 实测如此）⇒ 所有游戏**只能在设备上验**；
 *     · 设备那边对未解析调用是容忍的 ⇒ 游戏跑得动，但这些调用**全是空转**
 *       （用户早就报过「#57 调了没反应」）。
 *   宿主侧的 syscall 一直是好的（`VmlUiCalls` 的 534–539、`VmSpeakerBeep`、
 *   `DeviceDisplay.KeepScreenOn`、`Preferences`），缺的只是这一层
 *   「把 `ui_*` 标签接到号段」的包装。
 *
 * 几何是**归一化 0..1000 的整数**（千分之一），约定见 `Lib/c/waycoder_ui.h`。 */

void ui_gradient(char* id, int radial, int color_a, int color_b,
                 int a1, int a2, int a3, int a4) {
    asm("SYSCALL #534, ${id}, ${radial}, ${color_a}, ${color_b}, ${a1}, ${a2}, ${a3}, ${a4}");
}

void ui_path(char* d, int stroke, int width, int fill, char* grad, int cap, int dash) {
    asm("SYSCALL #535, ${d}, ${stroke}, ${width}, ${fill}, ${grad}, ${cap}, ${dash}");
}

/* pts 是 int 数组、每两个 int 一个点（x,y）；count 是**点数**不是数组长度。 */
void ui_polygon(int* pts, int count, int fill, int stroke, int width, char* grad) {
    asm("SYSCALL #536, ${pts}, ${count}, ${fill}, ${stroke}, ${width}, ${grad}");
}

void ui_polyline(int* pts, int count, int stroke, int width, char* grad) {
    asm("SYSCALL #537, ${pts}, ${count}, ${stroke}, ${width}, ${grad}");
}

void ui_rect_grad(int x, int y, int w, int h, char* grad, int radius) {
    asm("SYSCALL #538, ${x}, ${y}, ${w}, ${h}, ${grad}, ${radius}");
}

void ui_circle_grad(int cx, int cy, int r, char* grad) {
    asm("SYSCALL #539, ${cx}, ${cy}, ${r}, ${grad}");
}

/* ── 刷子 / 样式 / 一个号画所有形状（574–576）────────────────────────
 *
 * ## 为什么只有三个号
 *
 * VML 程序**不直接调 syscall** —— 它调这里的包装函数（22 门语言各有 GenLib 生成的绑定）。
 * **号是给库用的，不是给程序作者用的**，所以一个号可以靠"操作码"承担很多版本：
 * 加一个形状 = 加一个形状码 + 一个包装函数，**不用再占号**。
 *
 * ⚠ `${}` 占位符**只认变量名**（宏名、字面量都不认），所以操作码要先落到一个局部变量。
 *   这是实测校准过的写法（见 Lib/README-ui.md），别图省事写成 ${VML_SHAPE_STAR}。
 */

/* 操作码 —— 与宿主 `VmlShape` / `VmlBrushKind` / `VmlStyleSlot` 一一对应，
 * 也与 `Lib/c/waycoder_ui.h` 里给用户看的 `VML_CAP_*` / `VML_ARROW_*` 同族。
 * ⚠ **跨语言契约，只能末尾追加**。
 *
 * ⚠ 定义在**本文件**而不是头文件里：本文件（共享库的实现）并不 include 头文件 ——
 *   头文件是给**用户的 C 程序**用的（只有声明与常量）。两边是同一个契约，
 *   改一边必须改另一边（`scripts/check-vml-patches.sh` 的判据②a 会盯着生成物）。 */
#define VML_BRUSH_SOLID    0
#define VML_BRUSH_LINEAR   1
#define VML_BRUSH_RADIAL   2
#define VML_BRUSH_BY_NAME  3

#define VML_STYLE_FILL     0
#define VML_STYLE_PEN      1
#define VML_STYLE_TEXT     2

#define VML_SHAPE_RECT         0
#define VML_SHAPE_CIRCLE       1
#define VML_SHAPE_ELLIPSE      2
#define VML_SHAPE_LINE         3
#define VML_SHAPE_POLYGON      4
#define VML_SHAPE_POLYLINE     5
#define VML_SHAPE_PATH         6
#define VML_SHAPE_TEXT         7
#define VML_SHAPE_STAR         8
#define VML_SHAPE_REGULAR      9
#define VML_SHAPE_RING        10
#define VML_SHAPE_PIE         11
#define VML_SHAPE_HEART       12
#define VML_SHAPE_ELLIPSE_GRAD 13

/* 造刷子 → 句柄（>=1；0 = 失败）。颜色 = 0xAARRGGBB。 */
int ui_brush_solid(int color) {
    int op;
    op = VML_BRUSH_SOLID;
    return asm("SYSCALL #575, ${op}, ${color}");
}

/* 线性渐变刷子。几何是**千分之一**（0..1000）：x1 y1 x2 y2 相对形状自己的包围盒。 */
int ui_brush_linear(int color_a, int color_b, int x1, int y1, int x2, int y2) {
    int op;
    op = VML_BRUSH_LINEAR;
    return asm("SYSCALL #575, ${op}, ${color_a}, ${color_b}, ${x1}, ${y1}, ${x2}, ${y2}");
}

/* 径向渐变刷子：cx cy r 也是千分之一。 */
int ui_brush_radial(int color_a, int color_b, int cx, int cy, int r) {
    int op;
    op = VML_BRUSH_RADIAL;
    return asm("SYSCALL #575, ${op}, ${color_a}, ${color_b}, ${cx}, ${cy}, ${r}");
}

/* 按名字引用一个已经 ui_gradient 定义过的渐变 → 句柄（0 = 没有这个名字）。 */
int ui_brush_named(char* gradId) {
    int op;
    op = VML_BRUSH_BY_NAME;
    return asm("SYSCALL #575, ${op}, ${gradId}");
}

/* 设置填充刷子。**直接传颜色也合法**（颜色 = 只有一个色标的刷子）：ui_set_fill(0xFF2A3346)。 */
int ui_set_fill(int brush) {
    int slot;
    slot = VML_STYLE_FILL;
    return asm("SYSCALL #576, ${slot}, ${brush}, 0, 0, 0, 0");
}

/* 设置画笔（描边）：刷子 + 线宽 + 线帽 + 虚线 + 箭头。brush 传 0 = 不描边。 */
int ui_set_pen(int brush, int width, int cap, int dash, int arrow) {
    int slot;
    slot = VML_STYLE_PEN;
    return asm("SYSCALL #576, ${slot}, ${brush}, ${width}, ${cap}, ${dash}, ${arrow}");
}

/* 设置文字刷子（0 = 回到 ui_set_font 给的颜色）。 */
int ui_set_text_brush(int brush) {
    int slot;
    slot = VML_STYLE_TEXT;
    return asm("SYSCALL #576, ${slot}, ${brush}, 0, 0, 0, 0");
}

/* ── 形状（都走 #574，样式取自上面设的刷子）── */

void ui_draw_rect(int x, int y, int w, int h, int radius) {
    int op;
    op = VML_SHAPE_RECT;
    asm("SYSCALL #574, ${op}, ${x}, ${y}, ${w}, ${h}, ${radius}");
}

void ui_draw_circle(int cx, int cy, int r) {
    int op;
    op = VML_SHAPE_CIRCLE;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${r}");
}

void ui_draw_ellipse(int cx, int cy, int rx, int ry) {
    int op;
    op = VML_SHAPE_ELLIPSE;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${rx}, ${ry}");
}

void ui_draw_line(int x1, int y1, int x2, int y2) {
    int op;
    op = VML_SHAPE_LINE;
    asm("SYSCALL #574, ${op}, ${x1}, ${y1}, ${x2}, ${y2}");
}

/* 多边形（close=1 自动闭合）/ 折线（close=0）。pts 每两个 int 一个点，count 是**点数**。 */
void ui_draw_poly(int* pts, int count, int close) {
    int op;
    if (close != 0) { op = VML_SHAPE_POLYGON; } else { op = VML_SHAPE_POLYLINE; }
    asm("SYSCALL #574, ${op}, ${pts}, ${count}");
}

void ui_draw_path(char* d) {
    int op;
    op = VML_SHAPE_PATH;
    asm("SYSCALL #574, ${op}, ${d}");
}

void ui_draw_text(int x, int y, char* s) {
    int op;
    op = VML_SHAPE_TEXT;
    asm("SYSCALL #574, ${op}, ${x}, ${y}, ${s}");
}

/* 渐变填充的椭圆（自带渐变名，与 ui_rect_grad / ui_circle_grad 同形）。 */
void ui_ellipse_grad(int cx, int cy, int rx, int ry, char* grad) {
    int op;
    op = VML_SHAPE_ELLIPSE_GRAD;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${rx}, ${ry}, ${grad}");
}

void ui_draw_star(int cx, int cy, int r_out, int r_in, int points, int rot) {
    int op;
    op = VML_SHAPE_STAR;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${r_out}, ${r_in}, ${points}, ${rot}");
}

void ui_draw_regular(int cx, int cy, int r, int n, int rot) {
    int op;
    op = VML_SHAPE_REGULAR;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${r}, ${n}, ${rot}");
}

void ui_draw_ring(int cx, int cy, int r_out, int r_in) {
    int op;
    op = VML_SHAPE_RING;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${r_out}, ${r_in}");
}

void ui_draw_pie(int cx, int cy, int r, int a0, int a1) {
    int op;
    op = VML_SHAPE_PIE;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${r}, ${a0}, ${a1}");
}

void ui_draw_heart(int cx, int cy, int size) {
    int op;
    op = VML_SHAPE_HEART;
    asm("SYSCALL #574, ${op}, ${cx}, ${cy}, ${size}");
}

/* ── 手感：音效 / 震动 / 持久化 / 常亮 ──
 *
 * 音效走 **VM 内置的 #57 蜂鸣** —— 宿主把它截住接到真实音频（方波 + 3ms 包络），
 * 零素材、不必打包音频文件。 */

void ui_beep(int freq, int ms) {
    asm("SYSCALL #57, ${freq}, ${ms}");
}

/* 震动 —— 底层只有一个号（545）+ 操作码（v0.96.484 合并，原先 545/546 两个号）。
 *
 * ⚠ 参数**必须**是形参 —— `${形参}` 是按出现顺序装进 R0、R1…，
 *   在 asm 文本里塞字面量 `0` 不会落到对应寄存器（实测被丢掉），宿主读到的就是垃圾值。
 *   合并进 op 之后操作码自己也走形参，同一条道理。 */
#define VML_VIBRATE_OP_SIMPLE   0
#define VML_VIBRATE_OP_PATTERN  1

void ui_vibrate(int ms, int strength) {
    int op = VML_VIBRATE_OP_SIMPLE;
    asm("SYSCALL #545, ${op}, ${ms}, ${strength}");
}

/* 按节奏震动：`pattern` 是 int 数组（奇数下标=静、偶数下标=动，同 Android 语义），
 * `count` 是段数（上限见 VML_VIBRATE_MAX_SEGMENTS）。返回 0 成功 / -1 失败。 */
int ui_vibrate_pattern(int* pattern, int count) {
    int op = VML_VIBRATE_OP_PATTERN;
    return asm("SYSCALL #545, ${op}, ${pattern}, ${count}");
}

void ui_keep_on(int on) {
    asm("SYSCALL #553, ${on}");
}

/* 持久化。键由宿主统一加 `vml.` 前缀，不会和 App 自己的设置打架。
 * ⚠ 底层只有一个号（550）+ 操作码（v0.96.484 合并，原先 550/551/552 三个号）。 */
#define VML_STORE_OP_SET     0
#define VML_STORE_OP_GET     1
#define VML_STORE_OP_DELETE  2

void ui_store_set(char* key, char* value) {
    int op = VML_STORE_OP_SET;
    asm("SYSCALL #550, ${op}, ${key}, ${value}");
}

int ui_store_get(char* key, char* buf, int cap) {
    int op = VML_STORE_OP_GET;
    return asm("SYSCALL #550, ${op}, ${key}, ${buf}, ${cap}");
}

/* 删掉一条存档。返回 0 成功 / -1 失败（键非法）。 */
int ui_store_del(char* key) {
    int op = VML_STORE_OP_DELETE;
    return asm("SYSCALL #550, ${op}, ${key}");
}

/* ── 命令行参数（#62/#63，v0.96.371）────────────────────────────
 *
 * 参数由**宿主**喂：桌面上是 `vmlcli prog.c --arg -l --arg foo`，
 * 手机上是 `vml run examples/c/tetris.c -l`（多出来的 token 全部当参数）。
 * 编译产物里**不含**参数 ⇒ 同一个 `.vml` 可以带不同参数跑。
 *
 * `argv[0]` 是**程序名**（宿主决定；宿主一个参数都不给时它也一定在 ——
 * C 保证 `argc >= 1`，而老程序常拿 `argv[0]` 打用法）。所以用户给的第一个参数是 `ui_arg(1,…)`。
 *
 * ⚠ `int main(int argc, char **argv)` 的程序**不需要**这两个函数（入口帧直接给），
 *   它们是给 `int main(void)` 的程序、以及非 C 语言的绑定用的。
 *
 * 判据：`scripts/vml-c-probe/cases/45-argv-pass.c`（**两条路取到同一份**）。 */
int ui_argc(void) {
    return asm("SYSCALL #62");
}

/* 把第 i 个参数拷进调用方缓冲区（与 `ui_store_get` 同一套：宿主没有能"交还"的堆），
   返回**写入的字节数**（不含结尾 NUL）；i 越界 / 缓冲区无效返回 -1。
   容量不够就**截断**（照 C 的 `strncpy` 语义，一定补 NUL）。 */
int ui_arg(int i, char* buf, int cap) {
    return asm("SYSCALL #63, ${i}, ${buf}, ${cap}");
}

/* ── 通用宿主调用口（577–580，v0.96.326）──
 *
 * 四个函数的结构完全一样：**把数组的元素装进寄存器 + 发一条 syscall**。
 * 第 0 个元素是**调用号**（id），返回值写回第 0 号寄存器 —— 于是调用方
 * 拿不到原来传进去的 v[0]（这是 ABI 的一部分，见头文件那段）。
 * 宿主按 id 查注册表（两端共用 WayCoder/UI/Shared/VmlCallRegistry.cs）。
 *
 * ## 为什么 int8 直接排 8 个 `${}`，另外三个要绕一道指针
 *
 * `${局部量}` 展开出来的是**一条 32 位 `MOVE` 装载**（见本文件开头那段：
 * 形参/局部量按出现顺序落 R0、R1…）。int8 要的正好就是"32 位值进 R0–R7"，一拍即合。
 *
 * 但 float/long/double **不行**：`MOVE` 只搬 32 位，而且它**不碰浮点/长整数寄存器组** ——
 * 值进了通用寄存器，`F1`/`L1`/`D1` 里还是旧的。这三个组只能由
 * `MOVEF`/`MOVEL`/`MOVED` 写（运行时按操作数编码落到 `floatRegisters`/`longRegisters`/
 * `doubleRegisters`）。所以先把地址算进一个指针局部量，再用
 * `MOVEF F1, [R0]` 把**该类型的值**从内存直接读进对应的寄存器组。
 * 顺带一个好处：值全程没有被拆成低/高两半过（64 位的 long/double 用 `MOVE` 只能拿到低 32 位）。
 *
 * ## 调用号的整数视图
 *
 * 四个口的宿主都从 `R0` 读 id（"怎么读 id"在宿主侧只有一种写法）。int8 本来就是 R0；
 * 另外三个在装完类型寄存器之后再补一句 `id = (int)v[0]`，由前端生成一条
 * `F2I`/`L2I`/`D2I` 把整数视图放进 R0 —— 那一步**不会**碰 F0/L0/D0 里已经装好的值。
 * ⚠ 顺序不能反：先装类型寄存器、后写 R0（反过来 R0 会被 `MOVEF F0` 的低位镜像冲掉）。
 */

/* 8 个 int：v[0]=调用号 R0，v[1..7] → R1..R7；返回值覆盖 R0。 */
int callwithint8(int* v) {
    int a0 = v[0]; int a1 = v[1]; int a2 = v[2]; int a3 = v[3];
    int a4 = v[4]; int a5 = v[5]; int a6 = v[6]; int a7 = v[7];
    return asm("SYSCALL #577, ${a0}, ${a1}, ${a2}, ${a3}, ${a4}, ${a5}, ${a6}, ${a7}");
}

/* 8 个 float：v[0]=调用号 F0（同时 R0 放它的整数视图），v[1..7] → F1..F7；返回值覆盖 F0。 */
float callwithfloat8(float* v) {
    float* p;
    int id;
    p = v;     asm("MOVEF F0, [${p}]");
    p = v + 1; asm("MOVEF F1, [${p}]");
    p = v + 2; asm("MOVEF F2, [${p}]");
    p = v + 3; asm("MOVEF F3, [${p}]");
    p = v + 4; asm("MOVEF F4, [${p}]");
    p = v + 5; asm("MOVEF F5, [${p}]");
    p = v + 6; asm("MOVEF F6, [${p}]");
    p = v + 7; asm("MOVEF F7, [${p}]");
    id = (int)v[0];
    return asm("SYSCALL #578, ${id}");
}

/* 4 个 long：v[0]=调用号 L0（同时 R0 放它的整数视图），v[1..3] → L1..L3；返回值覆盖 L0。 */
long callwithlong4(long* v) {
    long* p;
    int id;
    p = v;     asm("MOVEL L0, [${p}]");
    p = v + 1; asm("MOVEL L1, [${p}]");
    p = v + 2; asm("MOVEL L2, [${p}]");
    p = v + 3; asm("MOVEL L3, [${p}]");
    id = (int)v[0];
    return asm("SYSCALL #579, ${id}");
}

/* 4 个 double：v[0]=调用号 D0（同时 R0 放它的整数视图），v[1..3] → D1..D3；返回值覆盖 D0。 */
double callwithdouble4(double* v) {
    double* p;
    int id;
    p = v;     asm("MOVED D0, [${p}]");
    p = v + 1; asm("MOVED D1, [${p}]");
    p = v + 2; asm("MOVED D2, [${p}]");
    p = v + 3; asm("MOVED D3, [${p}]");
    id = (int)v[0];
    return asm("SYSCALL #580, ${id}");
}
