#param lib("uscanf")
#param lib("wprintf")
#param lib("wscanf")

// VML Shared Printf Library v4 — 64位 + 完整格式化
//  %d %i %u %x %X %o %b %B %c %s %p  — 32位 整数/字符串
//  %ld %lu %lx %lX %lo %lb             — 64位 整数
//  %lld %llu %llx %llo %llb             — 64位 long long (同 long)
//  %f %e %E %g %G — **double64**（两个 int 槽: lo32, hi32）—— 与 C 一致
//  %lf %le %lE    — 同上（printf 里 `%f` 与 `%lf` 语义相同）
//  ⚠ 曾经 %f 读的是「一槽 float」、%lf 才是 double，而 %lf 那条分支是**空的**
//    ⇒ `printf("%f", 1.5)` 打出 0.0（1.5 是 double，低 32 位恰好 0x00000000）、
//       `printf("%lf", 任何东西)` 也打出 0.0。两者都已按 C 语义修正。
//  %ls %ws — wchar_t* / %us — char32_t*
//  宽度/精度/对齐: %5d %05d %-5d %3.2f
//  函数: sprintf / printf2..5 / printf64_2..5
//
#param lib("wchar")
#param lib("uchar")

// 变参一律走标准机制（`va_start` / `va_arg`）—— 实现由前端内建，见下面 printf 处的说明。
#include "stdarg.h"

extern size_t wcstombs(char *dest, const unsigned short *src, size_t max);
extern size_t ucs_to_utf8(const unsigned int *src, char *dest, size_t max);

// ====== 内部辅助 ======
static int emit(int buf, int pos, char c) {
    char *p = (char*)buf; if (p) p[pos] = c; return 1;
}
static int pad_char(int buf, int pos, char fill, int n) {
    int i, cnt = 0;
    for (i = 0; i < n; i++) cnt += emit(buf, pos + cnt, fill);
    return cnt;
}
static int putsn(int buf, int pos, const char *s, int maxlen) {
    int cnt = 0;
    if (!s) s = "(null)";
    while (*s && (maxlen < 0 || cnt < maxlen)) { cnt += emit(buf, pos + cnt, *s); s++; }
    return cnt;
}
static int slen(const char *s) {
    int n = 0; if (s) while (*s) { n++; s++; } return n;
}

// 32-bit itoa (base 2-16) — 前缀 _printf_ 避免与其他库冲突
static int _printf_itoa(char *tmp, unsigned int uv, int base, int upper) {
    int len = 0;
    do { int d = uv % base; tmp[len++] = (char)(d < 10 ? '0'+d : (upper?'A':'a')+d-10); uv /= base; } while (uv);
    return len;
}

// 64-bit itoa (base 2-16) — uv_lo/hi 组成 64 位无符号值
static int _printf_itoa64(char *tmp, unsigned int uv_lo, unsigned int uv_hi, int base, int upper) {
    int len = 0;
    // 长除法: 64-bit / base
    while (uv_hi != 0 || uv_lo != 0) {
        // 用 64-bit / 32-bit 长除法
        unsigned long long rem = 0;
        // 简化为逐位除法
        unsigned int q_hi = 0, q_lo = 0;
        int i; for (i = 63; i >= 0; i--) {
            int bit_hi = (i >= 32) ? ((uv_hi >> (i - 32)) & 1) : 0;
            int bit_lo = (i < 32)  ? ((uv_lo >> i) & 1) : 0;
            unsigned long long cur = (rem << 1) | (unsigned long long)((i >= 32) ? bit_hi : bit_lo);
            if (cur >= (unsigned long long)base) {
                unsigned long long qt = cur / (unsigned long long)base;
                rem = cur - qt * (unsigned long long)base;
                if (i >= 32) q_hi |= (unsigned int)(qt & 0xFFFFFFFF) << (i - 32);
                else        q_lo |= (unsigned int)(qt & 0xFFFFFFFF) << i;
            } else {
                rem = cur;
            }
        }
        tmp[len++] = (char)(rem < 10 ? '0' + (int)rem : (upper ? 'A' : 'a') + (int)rem - 10);
        uv_hi = q_hi; uv_lo = q_lo;
    }
    if (len == 0) tmp[len++] = '0';
    return len;
}

static int out_rev(int buf, int pos, const char *tmp, int len) {
    int i, cnt = 0;
    for (i = len - 1; i >= 0; i--) cnt += emit(buf, pos + cnt, tmp[i]);
    return cnt;
}

// 从 args 数组读取 64-bit 有符号长整数 (lo32, hi32)
// 副作用: *ai += 2 (已手动在外层调用)
static long long readLong(const int *args, int ai) {
    unsigned int lo = (unsigned int)args[ai];
    unsigned int hi = (unsigned int)args[ai + 1];
    return (long long)(((unsigned long long)hi << 32) | (unsigned long long)lo);
}

// 从 args 读取 double (2 slots: lo32, hi32)
//
// ⚠ **不要用 `((unsigned long long)hi << 32) | lo` 拼位** —— 实测本前端的 64 位
//   移位不工作：拿 `pair[1]=0x3FF80000, pair[0]=0`（1.5）走那条路，
//   得到的是 `0x3FF800003FF80000`（**两半都成了 hi**），再当 double 读就是 0。
//   `Lib/` 里所有 64 位函数都写成「lo/hi 两个 int 分开传」（见 `_printf_itoa64`
//   的形参表），正是为了绕开它 —— 这里也照那条路走。
//
// 正解：让两半在**内存里自然相邻**，再把那块内存按 double 读。零 64 位算术。
// 实测（`/tmp/d2.c`）：`pair={0,0x3FF80000}` ⇒ `d*1000 == 1500` ✓。
static double readDouble(const int *args, int ai) {
    int pair[2];
    pair[0] = args[ai];        // lo32
    pair[1] = args[ai + 1];    // hi32（VML 是小端，低字在前）
    double *dp = (double*)pair;
    return *dp;
}

// 64-bit 有符号 → 绝对值 + 符号标志
// 返回: 负数返回 1, 置 *lo/*hi 为绝对值
static int sign64(long long v, unsigned int *lo, unsigned int *hi) {
    if (v < 0) {
        unsigned long long abs = (unsigned long long)(-v);
        *lo = (unsigned int)(abs & 0xFFFFFFFF);
        *hi = (unsigned int)(abs >> 32);
        return 1;
    }
    *lo = (unsigned int)((unsigned long long)v & 0xFFFFFFFF);
    *hi = (unsigned int)((unsigned long long)v >> 32);
    return 0;
}

// float → string with precision
static int _printf_ftoa(char *buf, float f, int prec) {
    int len = 0;
    if (f < 0.0f) { buf[len++] = '-'; f = -f; }
    int ip = (int)f;
    float frac = f - (float)ip;
    if (frac < 0.0f) frac = -frac;
    char tmp[20]; int ilen = _printf_itoa(tmp, (unsigned int)ip, 10, 0);
    out_rev((int)(buf+len), 0, tmp, ilen); len += ilen;
    if (prec > 0) {
        buf[len++] = '.';
        frac = f - (float)((int)f); if (frac < 0) frac = -frac;
        int fi = 0, i; for (i = 0; i < prec; i++) { frac *= 10.0f; fi = fi * 10 + (int)frac; frac -= (float)(int)frac; }
        int flen = _printf_itoa(tmp, (unsigned int)fi, 10, 0);
        int p; for (p = flen; p < prec; p++) buf[len++] = '0';
        out_rev((int)(buf+len), 0, tmp, flen); len += flen;
    }
    return len;
}

// float → 科学计数法
static int _printf_ftoe(char *buf, float f, int prec, int upper) {
    int len = 0;
    if (f < 0.0f) { buf[len++] = '-'; f = -f; }
    if (prec < 0) prec = 6;
    int exp = 0;
    if (f != 0.0f) {
        if (f >= 10.0f)       { while (f >= 10.0f)  { f /= 10.0f; exp++; } }
        else if (f < 1.0f)    { while (f < 1.0f)    { f *= 10.0f; exp--; } }
    }
    int ip = (int)f;
    buf[len++] = (char)('0' + ip);
    if (prec > 0) {
        buf[len++] = '.';
        float frac = f - (float)ip;
        int i; for (i = 0; i < prec; i++) { frac *= 10.0f; buf[len++] = (char)('0' + (int)frac); frac -= (float)(int)frac; }
    }
    buf[len++] = (char)(upper ? 'E' : 'e');
    if (exp < 0) { buf[len++] = '-'; exp = -exp; }
    else         { buf[len++] = '+'; }
    if (exp < 10) buf[len++] = '0';
    char tmp[8]; int elen = _printf_itoa(tmp, (unsigned int)exp, 10, 0);
    out_rev((int)(buf+len), 0, tmp, elen); len += elen;
    return len;
}

// ====== 核心格式化引擎 ======
int vsnprintf(char *buf, const char *fmt, const int *args, int nargs) {
    int bufI = (int)buf, pos = 0, ai = 0;
    while (*fmt) {
        if (*fmt != '%') { pos += emit(bufI, pos, *fmt); fmt++; continue; }
        fmt++;
        // 解析标志
        int left = 0, zero = 0, alt = 0, width = 0, prec = -1;
        while (1) {
            if      (*fmt == '-')      { left = 1; fmt++; }
            else if (*fmt == '0')      { zero = 1; fmt++; }
            else if (*fmt == '#')      { alt = 1;  fmt++; }
            else break;
        }
        while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        if (*fmt == '.') { fmt++; prec = 0; while (*fmt >= '0' && *fmt <= '9') { prec = prec * 10 + (*fmt - '0'); fmt++; } }

        // 长度修饰符
        int is64 = 0;
        if (*fmt == 'l') { fmt++; is64 = 1;
            if (*fmt == 'l') { fmt++; } // %lld 等同 %ld
        } else if (*fmt == 'h') { fmt++; if (*fmt == 'h') fmt++; }

        // ⚠ `%%` 必须在这里处理 —— 它**不消耗任何实参**。
        //   此前它靠下面分派链尾部的 `else if (*fmt == '%')` 兜，但那已经太晚了：
        //   中间这段「读取参数值」在 ai >= nargs 时会走 `else { fmt++; continue; }`
        //   ⇒ `printf("100%%")` 这种（没有实参）会把第二个 `%` 悄悄吃掉、
        //   **一个字都不输出、pos 也不增**，而且没有任何报错。
        //   实测 `vsnprintf(b,"P=%%",args,0)` 得 len=2、buf=`P=`（应为 len=3、`P=%`）。
        if (*fmt == '%') { pos += emit(bufI, pos, '%'); fmt++; continue; }

        // 读取参数值
        int val = 0;
        long long val64 = 0;
        int argStart = ai;   // %f 系列要**回头**从这两个槽重读一个 double，故记下起点
        if (is64 && ai + 1 < nargs) {
            val64 = readLong(args, ai);
            ai += 2;
        } else if (ai < nargs) {
            val = args[ai];
            ai++;
        } else { fmt++; continue; }

        if (*fmt == 'd' || *fmt == 'i') {
            char tmp[40]; int len, out_len, neg = 0;
            if (is64) {
                unsigned int lo, hi; neg = sign64(val64, &lo, &hi);
                len = _printf_itoa64(tmp, lo, hi, 10, 0);
            } else {
                unsigned int uv; if (val < 0) { neg = 1; uv = (unsigned int)(-val); } else uv = (unsigned int)val;
                len = _printf_itoa(tmp, uv, 10, 0);
            }
            out_len = len + (neg ? 1 : 0);
            if (!left && !zero) pos += pad_char(bufI, pos, ' ', width - out_len);
            if (neg) pos += emit(bufI, pos, '-');
            if (zero) pos += pad_char(bufI, pos, '0', width - out_len);
            pos += out_rev(bufI, pos, tmp, len);
            if (left) pos += pad_char(bufI, pos, ' ', width - out_len);
            fmt++;
        } else if (*fmt == 'u' || *fmt == 'x' || *fmt == 'X' || *fmt == 'o' || *fmt == 'b') {
            int base = *fmt == 'x' || *fmt == 'X' ? 16 : *fmt == 'o' ? 8 : *fmt == 'b' ? 2 : 10;
            int upper = (*fmt == 'X');
            char tmp[80]; int len;
            if (is64) {
                unsigned int lo = (unsigned int)((unsigned long long)val64 & 0xFFFFFFFF);
                unsigned int hi = (unsigned int)((unsigned long long)val64 >> 32);
                len = _printf_itoa64(tmp, lo, hi, base, upper);
            } else {
                len = _printf_itoa(tmp, (unsigned int)val, base, upper);
            }
            int prefix_len = 0;
            if (alt) {
                int isZero = is64 ? (val64 == 0) : (val == 0);
                if (!isZero) {
                    if (base == 16) { pos += emit(bufI, pos, '0'); pos += emit(bufI, pos, upper ? 'X' : 'x'); prefix_len = 2; }
                    else if (base == 8)  { pos += emit(bufI, pos, '0'); prefix_len = 1; }
                    else if (base == 2)  { pos += emit(bufI, pos, '0'); pos += emit(bufI, pos, 'b'); prefix_len = 2; }
                }
            }
            int out_len = len + prefix_len;
            if (!left && !zero) pos += pad_char(bufI, pos, ' ', width - out_len);
            if (zero) pos += pad_char(bufI, pos, '0', width - out_len);
            pos += out_rev(bufI, pos, tmp, len);
            if (left) pos += pad_char(bufI, pos, ' ', width - out_len);
            fmt++;
        } else if (*fmt == 'c') {
            if (!left) pos += pad_char(bufI, pos, ' ', width - 1);
            pos += emit(bufI, pos, (char)val);
            if (left) pos += pad_char(bufI, pos, ' ', width - 1);
            fmt++;
        } else if (*fmt == 's') {
            const char *s = (const char *)val; int sl = slen(s);
            if (!left) pos += pad_char(bufI, pos, ' ', width - sl);
            pos += putsn(bufI, pos, s, prec >= 0 ? prec : -1);
            if (left) pos += pad_char(bufI, pos, ' ', width - sl);
            fmt++;
        } else if ((*fmt == 'l' || *fmt == 'w') && (fmt[1] == 's')) {
            char wbuf[512]; wcstombs(wbuf, (const unsigned short *)val, 511);
            int sl = slen(wbuf);
            if (!left) pos += pad_char(bufI, pos, ' ', width - sl);
            pos += putsn(bufI, pos, wbuf, prec >= 0 ? prec : -1);
            if (left) pos += pad_char(bufI, pos, ' ', width - sl);
            fmt += 2;
        } else if (*fmt == 'u' && fmt[1] == 's') {
            char wbuf[512]; ucs_to_utf8((const unsigned int *)val, wbuf, 511);
            int sl = slen(wbuf);
            if (!left) pos += pad_char(bufI, pos, ' ', width - sl);
            pos += putsn(bufI, pos, wbuf, prec >= 0 ? prec : -1);
            if (left) pos += pad_char(bufI, pos, ' ', width - sl);
            fmt += 2;
        } else if (*fmt == 'p') {
            pos += putsn(bufI, pos, "0x", -1);
            char tmp[20]; int len = _printf_itoa(tmp, (unsigned int)val, 16, 0);
            pos += out_rev(bufI, pos, tmp, len); fmt++;
        } else if (*fmt == 'f' || *fmt == 'e' || *fmt == 'E' || *fmt == 'g' || *fmt == 'G') {
            if (prec < 0) prec = 6;
            char fbuf[60]; int flen;
            // ⚠ `%f`/`%e`/`%g` 消费的是**一整个 double（两个槽）**，不是一槽 float。
            //
            //   判据是 C 的可变参数默认提升：`printf("%f", x)` 里 x 无论是 float 还是
            //   double，**到达 printf 时一律是 double**。此前这里读的是 `*(float*)&val`
            //   ——只取了低 32 位，于是：
            //     · `printf("%f", 1.5)`：1.5 是 double，低字 0x00000000 ⇒ 打出 `0.0`
            //     · `printf("%f", x)`（x 是 float 变量）：1 槽、位模式正好落在低字 ⇒ 1.5 ✓
            //   也就是「对错取决于实参的静态类型」——运行期无从分辨，只能按 C 定死成 double。
            //   配套：C 前端的调用点会把 float 实参**提升成 double**（见
            //   `CCompiler/CodeGenerator.Expressions.Calls.cs` 的「可变参数默认提升」），
            //   所以 `printf("%f", floatVar)` 依旧正确。
            double dv = (argStart + 1 < nargs) ? readDouble(args, argStart) : 0.0;
            ai = argStart + 2;          // 固定消费两个槽（is64 与否一视同仁）
            float fv = (float)dv;
            if (*fmt == 'e' || *fmt == 'E') {
                flen = _printf_ftoe(fbuf, fv, prec, (*fmt == 'E'));
            } else if (*fmt == 'g' || *fmt == 'G') {
                float af = fv; if (af < 0) af = -af;
                int use_exp = (af != 0.0f && (af >= 1000000.0f || af < 0.001f));
                if (!use_exp) { flen = _printf_ftoa(fbuf, fv, prec > 0 ? prec : 6); }
                else          { flen = _printf_ftoe(fbuf, fv, prec - 1, (*fmt == 'G')); }
            } else {
                flen = _printf_ftoa(fbuf, fv, prec);
            }
            if (!left) pos += pad_char(bufI, pos, ' ', width - flen);
            pos += putsn(bufI, pos, fbuf, flen);
            if (left) pos += pad_char(bufI, pos, ' ', width - flen);
            fmt++;
        } else if (*fmt == '%') {
            pos += emit(bufI, pos, '%'); fmt++;
        } else { pos += emit(bufI, pos, *fmt); fmt++; }
    }
    return pos;
}

// ====== Public API ======

// ⚠ 变参表 = 「紧跟 `fmt` 槽的那一个槽」，写法必须**按元素步长走**：
//   `&fmt` 是 `const char**`，写成 `&fmt + 4` 会按 4 字节缩放成 **+16 字节**，
//   正好是 fmt 之后的**第 4 个**槽 —— `printf` 只有一个形参、变参紧跟其后，
//   它碰巧落对；`sprintf` 多一个 `buf` 形参，于是整个读偏：
//   实测 `sprintf(b,"s=[%s]","abc")` 打出 `s=[s=[%s]]`（`%s` 读到了格式串自己）、
//   `sprintf(b,"ab%dcd",9)` 打出 `ab` + 地址的十进制 + `cd`。
//   转成 `int*` 再加 1 才是「下一个槽」，与形参个数无关。
/// <summary>
/// 数一数格式串里有几个**消耗实参**的转换符（`%%` 不算）。
///
/// ⚠ 这份判据**只有一处实现**（`scanf.c` 原先自带一份 static 的，已改为调这里）——
///   "同一规则两处实现"是本仓排第一的坑，而它在这里的后果很具体：
///   数错一个 ⇒ 变参表**整体错位一格**，`printf("%s %d", …)` 会把整数当指针解引用。
/// </summary>
int format_arg_count(const char *format) {
    int n = 0;
    const char *p = format;
    while (*p) {
        if (*p == '%') {
            p++;
            if (*p == '%' || *p == 0) { }
            else { n++; }
        }
        p++;
    }
    return n;
}

// ⚠ **变参一律走 `va_list`，不许拿形参地址自己算偏移**（用户定的硬规矩，
//   见 ROADMAP 第零节「自接读写地址的代码不要」）。
//
//   此前这两处写的是 `int *stack_args = (int*)&fmt + 1;` —— 那是**猜**栈布局：
//   它假定"变参紧跟 `fmt` 那一槽"，而这既不是语言契约、也与形参个数耦合
//   （注释里就记着它因此读偏过一次，`sprintf` 多一个 `buf` 形参就整体错位）。
//   换个前端（Python 等**没有指针**、按另一套约定传参）这条路直接断掉 ——
//   而共享库存在的意义正是"多语言共用同一份实现"。
//
//   `va_start/va_arg` 由**前端的内建**实现（`Lib/c/stdarg.h` → `__builtin_va_*`），
//   那是标准机制、由编译器负责，不是我们手写的地址算术。`scanf.c` 一直是这么做的。
#define PRINTF_MAX_ARGS 16

__cdecl void printf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);

    int nargs = format_arg_count(fmt);
    if (nargs > PRINTF_MAX_ARGS) nargs = PRINTF_MAX_ARGS;
    int args[PRINTF_MAX_ARGS];
    int i;
    for (i = 0; i < nargs; i++) args[i] = va_arg(ap, int);
    va_end(ap);

    char buf[512];
    int len = vsnprintf(buf, fmt, args, nargs);
    buf[len] = 0;
    int dummy = (int)buf;
    asm("SYSCALL #1");
}

__cdecl int sprintf(char *buf, const char *fmt, ...) {
    va_list ap;                            // 见上面 printf 处的说明（不许拿形参地址算偏移）
    va_start(ap, fmt);
    int nargs = format_arg_count(fmt);
    if (nargs > PRINTF_MAX_ARGS) nargs = PRINTF_MAX_ARGS;
    int args[PRINTF_MAX_ARGS];
    int i;
    for (i = 0; i < nargs; i++) args[i] = va_arg(ap, int);
    va_end(ap);

    int n = vsnprintf(buf, fmt, args, nargs);

    // ⚠ **必须自己补结尾的 NUL** —— `vsnprintf` 返回的是**长度**（不含结尾符），
    //   而 C 的 `sprintf` 契约是"写一个以 NUL 结尾的串"。
    //   此前这里直接 `return vsnprintf(...)`，**一个结尾符都不写** ⇒
    //   目标缓冲区后面残留什么，串就"长"成什么：
    //   实测 `strcpy(buf,"abcd"); sprintf(buf,"%d-%d",3,7)` 得到 **`3-7d`**（长度 4 而不是 3）
    //   —— `d` 正是上一句 `strcpy` 留在 `buf[3]` 的残渣。而**单独**写同一句是对的
    //   （缓冲区刚分配、后面本来就是 0）⇒ 这条缺陷最坑的形态：**换个上下文就自己变绿**，
    //   孤立用例永远抓不到（`scripts/vml-c-probe/08-sprintf.c` 就是因此才带着前置字符串操作）。
    //
    //   对老程序的影响面：状态栏、日志、`cprintf` 这类"先拼串再输出"的写法**全都会多尾巴**，
    //   而且多出来的内容**取决于上一次往该缓冲区写过什么** —— 典型的"编得过、跑起来才错"。
    buf[n] = 0;
    return n;
}

/// <summary>
/// `snprintf` —— **此前只有声明没有实现**（`Lib/c/stdio.h:55` 声明了它，全 `Lib/` 里
/// 搜不到任何定义）⇒ 老程序一用它就**链不上**。而它恰恰是"安全拼串"最常用的那个
/// （老代码里 `snprintf(buf, sizeof(buf), …)` 遍地都是）。
///
/// 返回值按 **C99**：给"**本该**写入的长度"（不含结尾符）—— 调用方靠 `>= size`
/// 判断有没有被截断。缓冲区本身**一定**以 NUL 结尾（`size > 0` 时）。
/// </summary>
__cdecl int snprintf(char *buf, unsigned int size, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int nargs = format_arg_count(fmt);
    if (nargs > PRINTF_MAX_ARGS) nargs = PRINTF_MAX_ARGS;
    int args[PRINTF_MAX_ARGS];
    int i;
    for (i = 0; i < nargs; i++) args[i] = va_arg(ap, int);
    va_end(ap);

    // 先整份格式化到临时缓冲，再按 size 截断 —— `vsnprintf` 收的是"参数数组"、
    // **不带长度上限**，所以边界只能在搬这一趟时守。临时缓冲与 printf 用同一个尺寸，
    // 超过就按 printf 的既有行为截断（那条路本来也没有上限）。
    char tmp[512];
    int n = vsnprintf(tmp, fmt, args, nargs);
    tmp[n] = 0;

    int lim = (int)size;          // size_t = unsigned int，先转有符号免得 size-1 下溢成天文数字
    if (lim > 0) {
        int k = 0;
        while (k < lim - 1 && tmp[k] != 0) { buf[k] = tmp[k]; k++; }
        buf[k] = 0;
    }
    return n;
}

// 固定参数版本 (32-bit)
int printf2(char *buf, const char *fmt, int a1, int a2)     { int args[]={a1,a2};       return vsnprintf(buf, fmt, args, 2); }
int printf3(char *buf, const char *fmt, int a1, int a2, int a3) { int args[]={a1,a2,a3}; return vsnprintf(buf, fmt, args, 3); }
int printf4(char *buf, const char *fmt, int a1, int a2, int a3, int a4) { int args[]={a1,a2,a3,a4}; return vsnprintf(buf, fmt, args, 4); }
int printf5(char *buf, const char *fmt, int a1, int a2, int a3, int a4, int a5) { int args[]={a1,a2,a3,a4,a5}; return vsnprintf(buf, fmt, args, 5); }
