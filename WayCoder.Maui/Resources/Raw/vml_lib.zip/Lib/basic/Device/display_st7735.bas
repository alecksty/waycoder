﻿' ST7735寄存器定义
' 生成自: Sitronix/Display/ST7735
' 版本: 1.0
' 日期: 2026-05-06
' 作者: VML Team
' 描述: ST7735 1.8" 128x160 TFT LCD Display (SPI, 16-bit color)

' CPU架构: Display
' 位宽: 16位
' 时钟频率: 16000000 Hz

' 内存段定义
' Graphics RAM (128x160x16bit)
CONST GRAM_START = 0x00
CONST GRAM_END = 0x4FFF
CONST GRAM_SIZE = 20480

' 外设定义
' ST7735 128x160 TFT (SPI, 3.3V-5V)
CONST ST7735_BASE = 0x00
CONST ST7735_CMD = 0x00
CONST ST7735_DATA = 0x01
CONST ST7735_COL_START = 0x2A
CONST ST7735_ROW_START = 0x2B
CONST ST7735_WRITE_RAM = 0x2C
CONST ST7735_MADCTL = 0x36
CONST ST7735_COLMOD = 0x3A
CONST ST7735_INVON = 0x21
CONST ST7735_SLEEP_OUT = 0x11
CONST ST7735_DISP_ON = 0x29

' 设备初始化子程序
SUB st7735_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
