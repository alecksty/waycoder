﻿' MAX7219寄存器定义
' 生成自: Maxim/LED/MAX7219
' 版本: 1.0
' 日期: 2026-05-06
' 作者: VML Team
' 描述: MAX7219 8-Digit LED Display Driver (SPI, daisy-chainable, 8x8 matrix)

' CPU架构: LED
' 位宽: 8位
' 时钟频率: 10000000 Hz

' 外设定义
' MAX7219 8-Digit/8x8 Matrix Driver (4.0V-5.5V, DIP-24)
CONST MAX7219_BASE = 0x00
CONST MAX7219_DIGIT0 = 0x01
CONST MAX7219_DIGIT1 = 0x02
CONST MAX7219_DIGIT2 = 0x03
CONST MAX7219_DIGIT3 = 0x04
CONST MAX7219_DIGIT4 = 0x05
CONST MAX7219_DIGIT5 = 0x06
CONST MAX7219_DIGIT6 = 0x07
CONST MAX7219_DIGIT7 = 0x08
CONST MAX7219_DECODE = 0x09
CONST MAX7219_INTENSITY = 0x0A
CONST MAX7219_SCAN_LIMIT = 0x0B
CONST MAX7219_SHUTDOWN = 0x0C
CONST MAX7219_TEST = 0x0F

' 设备初始化子程序
SUB max7219_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
