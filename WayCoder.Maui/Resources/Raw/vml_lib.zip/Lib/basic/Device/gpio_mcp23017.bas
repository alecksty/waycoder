﻿' MCP23017寄存器定义
' 生成自: Microchip/GPIO/MCP23017
' 版本: 1.0
' 日期: 2026-05-06
' 作者: VML Team
' 描述: MCP23017 16-bit I2C GPIO Expander (2 banks, interrupt, 25mA per pin)

' CPU架构: GPIO
' 位宽: 16位
' 时钟频率: 400000 Hz

' 外设定义
' MCP23017 16-bit GPIO (0x20-0x27, 1.8V-5.5V)
CONST MCP23017_BASE = 0x20
CONST MCP23017_IODIRA = 0x00
CONST MCP23017_IODIRB = 0x01
CONST MCP23017_GPIOA = 0x12
CONST MCP23017_GPIOB = 0x13
CONST MCP23017_GPINTENA = 0x04
CONST MCP23017_GPINTENB = 0x05
CONST MCP23017_INTCONA = 0x08
CONST MCP23017_IOCON = 0x0A
CONST MCP23017_GPPUA = 0x0C
CONST MCP23017_GPPUB = 0x0D

' 中断向量定义
CONST INTA_VECTOR = 0  ' Port A interrupt
CONST INTB_VECTOR = 1  ' Port B interrupt

' 设备初始化子程序
SUB mcp23017_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
