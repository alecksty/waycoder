﻿' ATtiny13寄存器定义
' 生成自: Atmel/AVR/ATtiny13
' 版本: 1.0
' 日期: 2026-04-28
' 作者: VML Team
' 描述: 8-bit AVR MCU with 1KB Flash, 64B RAM, 64B EEPROM, 20MHz, tiny

' CPU架构: AVR
' 位宽: 8位
' 时钟频率: 20000000 Hz

' 寄存器定义
CONST R0 = 0x00

CONST R1 = 0x01

CONST R2 = 0x02

CONST R16 = 0x10

CONST R17 = 0x11

' XL
CONST R26 = 0x1A

' XH
CONST R27 = 0x1B

' YL
CONST R28 = 0x1C

' YH
CONST R29 = 0x1D

' ZL
CONST R30 = 0x1E

' ZH
CONST R31 = 0x1F

' Stack Pointer Low
CONST SPL = 0x5D

' Stack Pointer High
CONST SPH = 0x5E

' Status Register
CONST SREG = 0x5F

' 内存段定义
CONST FLASH_START = 0x0000
CONST FLASH_END = 0x03FF
CONST FLASH_SIZE = 1024

CONST SRAM_START = 0x0060
CONST SRAM_END = 0x009F
CONST SRAM_SIZE = 64

CONST EEPROM_START = 0x0000
CONST EEPROM_END = 0x003F
CONST EEPROM_SIZE = 64

CONST IO_START = 0x00
CONST IO_END = 0x1F
CONST IO_SIZE = 32

CONST EXTIO_START = 0x20
CONST EXTIO_END = 0x5F
CONST EXTIO_SIZE = 64

' 外设定义
' Port B (only port)
CONST PORTB_BASE = 0x18
CONST PORTB_DDRB = 0x17
CONST PORTB_PORTB = 0x18
CONST PORTB_PINB = 0x19
CONST PORTB_PB0 = 0  ' Port B bit 0
CONST PORTB_PB1 = 1  ' Port B bit 1
CONST PORTB_PB2 = 2  ' Port B bit 2
CONST PORTB_PB3 = 3  ' Port B bit 3
CONST PORTB_PB4 = 4  ' Port B bit 4
CONST PORTB_PB5 = 5  ' Port B bit 5

' 8-bit Timer/Counter0
CONST TIMER0_BASE = 0x33
CONST TIMER0_TCCR0A = 0x33
CONST TIMER0_TCCR0B = 0x33
CONST TIMER0_TCNT0 = 0x32
CONST TIMER0_OCR0A = 0x36
CONST TIMER0_OCR0B = 0x35
CONST TIMER0_TIMSK0 = 0x39
CONST TIMER0_TIFR0 = 0x38

' Analog-to-Digital
CONST ADC_BASE = 0x04
CONST ADC_ADMUX = 0x07
CONST ADC_ADCSRA = 0x06
CONST ADC_ADCL = 0x04
CONST ADC_ADCH = 0x05

' 中断向量定义
CONST RESET_VECTOR = 1  ' 
CONST INT0_VECTOR = 2  ' External Interrupt 0
CONST PCINT0_VECTOR = 3  ' Pin Change Interrupt
CONST TIM0_OVF_VECTOR = 4  ' Timer0 Overflow
CONST TIM0_COMPA_VECTOR = 5  ' Timer0 Compare A
CONST WDT_VECTOR = 6  ' Watchdog Timeout
CONST ADC_VECTOR = 7  ' ADC Conversion Complete

' 设备初始化子程序
SUB attiny13_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
