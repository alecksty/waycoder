﻿' A4988寄存器定义
' 生成自: Allegro/Motor/A4988
' 版本: 1.0
' 日期: 2026-05-06
' 作者: VML Team
' 描述: A4988 Stepper Motor Driver (up to 1/16 microstepping, 2A, 8V-35V)

' CPU架构: Motor
' 位宽: 8位
' 时钟频率: 0 Hz

' 外设定义
' A4988 Stepper Motor Driver (3.3V/5V logic)
CONST A4988_BASE = 0x00
CONST A4988_CTRL = 0x00
CONST A4988_CTRL_STEP = 0  ' Step pulse (rising edge)
CONST A4988_CTRL_DIR = 1  ' Direction (0=CW, 1=CCW)
CONST A4988_CTRL_ENABLE = 2  ' Enable (active low)
CONST A4988_CTRL_SLEEP = 3  ' Sleep mode (active low)
CONST A4988_CTRL_RESET = 4  ' Reset (active low)
CONST A4988_MICROSTEP = 0x01
CONST A4988_MICROSTEP_MS1 = 0  ' Microstep select 1
CONST A4988_MICROSTEP_MS2 = 1  ' Microstep select 2
CONST A4988_MICROSTEP_MS3 = 2  ' Microstep select 3
CONST A4988_STEPS = 0x02
CONST A4988_DELAY_US = 0x06

' 设备初始化子程序
SUB a4988_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
