﻿' Commodore-PET寄存器定义
' 生成自: Commodore International/PET/Commodore-PET
' 版本: 1.0
' 日期: 2026-04-17
' 作者: VML Team
' 描述: Commodore PET 2001 personal computer with MOS 6502 CPU and built-in monitor

' CPU架构: MOS 6502
' 位宽: 8位
' 时钟频率: 1000000 Hz

' 寄存器定义
' Accumulator
CONST A = 0

' Index Register X
CONST X = 0

' Index Register Y
CONST Y = 0

' Stack Pointer
CONST SP = 0

' Program Counter
CONST PC = 0

' Status Register
CONST P = 0

' 外设定义
' Peripheral Interface Adapter 1 (6520)
CONST PIA1_BASE = 
CONST PIA1_PIA1_DDRA = 0xE810
CONST PIA1_PIA1_ORA = 0xE811
CONST PIA1_PIA1_DDRB = 0xE812
CONST PIA1_PIA1_ORB = 0xE813
CONST PIA1_PIA1_CRA = 0xE814
CONST PIA1_PIA1_CRB = 0xE815

' Peripheral Interface Adapter 2 (6520)
CONST PIA2_BASE = 
CONST PIA2_PIA2_DDRA = 0xE820
CONST PIA2_PIA2_ORA = 0xE821
CONST PIA2_PIA2_DDRB = 0xE822
CONST PIA2_PIA2_ORB = 0xE823
CONST PIA2_PIA2_CRA = 0xE824
CONST PIA2_PIA2_CRB = 0xE825

' Versatile Interface Adapter (6522)
CONST VIA_BASE = 
CONST VIA_VIA_ORB = 0xE840
CONST VIA_VIA_ORA = 0xE841
CONST VIA_VIA_DDRB = 0xE842
CONST VIA_VIA_DDRA = 0xE843
CONST VIA_VIA_T1CL = 0xE844
CONST VIA_VIA_T1CH = 0xE845
CONST VIA_VIA_T1LL = 0xE846
CONST VIA_VIA_T1LH = 0xE847
CONST VIA_VIA_T2CL = 0xE848
CONST VIA_VIA_T2CH = 0xE849
CONST VIA_VIA_SR = 0xE84A
CONST VIA_VIA_ACR = 0xE84B
CONST VIA_VIA_PCR = 0xE84C
CONST VIA_VIA_IFR = 0xE84D
CONST VIA_VIA_IER = 0xE84E

' CRT Controller (6545)
CONST CRTC_BASE = 
CONST CRTC_CRTC_ADDR = 0xE880
CONST CRTC_CRTC_DATA = 0xE881

' Cassette tape interface
CONST CASSETTE_BASE = 
CONST CASSETTE_CASS_MOTOR = 0xE840
CONST CASSETTE_CASS_WRITE = 0xE842
CONST CASSETTE_CASS_READ = 0xE812

' IEEE-488 bus interface
CONST IEEE488_BASE = 
CONST IEEE488_IEEE_DATA = 0xE801
CONST IEEE488_IEEE_STATUS = 0xE802
CONST IEEE488_IEEE_CONTROL = 0xE803

' 中断向量定义
CONST NMI_VECTOR = 65526  ' Non-maskable interrupt
CONST RESET_VECTOR = 65528  ' Reset vector
CONST IRQ_VECTOR = 65530  ' Interrupt request
CONST BRK_VECTOR = 65532  ' Break instruction

' 设备初始化子程序
SUB commodore_pet_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
