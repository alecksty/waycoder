﻿' ILI9341寄存器定义
' 生成自: Ilitek/Display/ILI9341
' 版本: 1.0
' 日期: 2026-05-06
' 作者: VML Team
' 描述: ILI9341 2.8" 240x320 TFT LCD Display (SPI, 18-bit color, touch)

' CPU架构: Display
' 位宽: 18位
' 时钟频率: 20000000 Hz

' 内存段定义
' Graphics RAM (240x320x18bit)
CONST GRAM_START = 0x00
CONST GRAM_END = 0xBCFF
CONST GRAM_SIZE = 156672

' 外设定义
' ILI9341 240x320 TFT (SPI, 3.3V, 2.8inch)
CONST ILI9341_BASE = 0x00
CONST ILI9341_CMD = 0x00
CONST ILI9341_DATA = 0x01
CONST ILI9341_COL_START = 0x2A
CONST ILI9341_PAGE_START = 0x2B
CONST ILI9341_WRITE_RAM = 0x2C
CONST ILI9341_MADCTL = 0x36
CONST ILI9341_PIXFMT = 0x3A
CONST ILI9341_FRMCTL = 0xB1
CONST ILI9341_GAMMA = 0x26
CONST ILI9341_SLEEP_OUT = 0x11
CONST ILI9341_DISP_ON = 0x29

' 设备初始化子程序
SUB ili9341_init()
    ' 初始化代码
END SUB

' 常用函数
FUNCTION read_register(addr AS INTEGER) AS INTEGER
    ' 读取寄存器值
    RETURN PEEK(addr)
END FUNCTION

SUB write_register(addr AS INTEGER, value AS INTEGER)
    ' 写入寄存器值
    POKE addr, value
END SUB
